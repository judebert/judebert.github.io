/*
 *  Copyright (C) 2000, 2003 by Jude Anthony
 *  http://judebert.cjb.net/
 *
 *  This file is part of Contraction Timer.
 *
 *  Contraction Timer is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  Contraction Timer is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Contraction Timer; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

// Finally needed a Boolean; must include PalmOS.h for data types
#include <PalmOS.h>

// Define program-only variables and structures here
#define CTIM_ID 'CTIM'
#define CTIM_STATSTYPE 'baby'
#define CTIM_STATSNAME "Contraction Log"

// While counter update rate is in 100th of a sec, timeouts are in sec
#define COUNTER_UPDATE_RATE 50
#define NOTIFY_FLASH_TIMEOUT 1
#define NOTIFY_SOUND_TIMEOUT 30

// Export types
#define CTIM_EXPORT_TEXT 0
#define CTIM_EXPORT_CSV 1

typedef struct {
    long start_secs;
    long end_secs;
    long log_len;
} contraction_stats;

typedef struct
{
    int was_editing;
    int selected_line;
    long notify_freq;
    Boolean notifying;
    long last_sound_notify;
    long last_flash_notify;
} program_state;
