/*
 *  Copyright (C) 2000, 2003 by Jude Anthony
 *  http://judebert.cjb.net/
 *
 *  This file is part of Contraction Timer.
 *
 *  Contraction Timer is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  Contraction Timer is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with Contraction Timer; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "ctimer.h"
#include "ctimer.rh" 
#include <PalmOS.h>
#include <PalmCompatibility.h>

/* Forward function declarations */
Word StartApplication(void);
Word StopApplication(void);
Boolean MainFormHandler(EventPtr evt);
Boolean EditFormHandler(EventPtr evt);
int WriteStats(void);
int WriteNote(int rcdX, char *notebuf);
//--JAM: int WriteEvents(int rcdx, char *events);
void ClearStats(void);
void ReloadStats(void);
void LoadStat(int index, contraction_stats *cs);
void LoadNote(int index, char *buf);
void ChangeLabel(int button_id, char *new_label);
void SecsTo5Chars(long seconds, char *str); 
void SecsToDuration(long seconds, char *str);
void SecsToFullDateTime(long seconds, char *str);
void DynamicStrCopy(char **dest, char *src);
void HighlightRow(int the_row);
void Scroll_Up(void);
void Scroll_Down(void);
void ExportToMemoPad(void);
void *InitMemo(DmOpenRef inDb, VoidHand *bufH, char *mother_name, int part);
void TextToMemo(DmOpenRef dbMemo, MemHandle bufH);
void UpdateCounter(void);
void Notify(void);
void UpdateNotificationIndicator(void);
long PreviousStartSecs(int record);

/* Global variables */
long update_rate = evtWaitForever; // How long to wait in event loop
contraction_stats stats;        // Current event start and end time 
DmOpenRef dbStats = 0;          // The event database
char *ButtonTexts[16];          // Labels of all buttons in display
char ElapsedText[200];          // Label of elapsed time counter button
char note[200];                 // Note buffer (multiple subroutines use it)
long prevstart = 0;             // Previous start time, for frequency calcs
#define DEFAULT_NOTIFY_FREQ 180
long notify_freq = 
    DEFAULT_NOTIFY_FREQ;        // Frequency at which to make notification
Boolean notify = false;         // True after frequency is achieved
long last_flash_notify = 0;     // Time of last notification by flash
long last_sound_notify = 0;     // Time of last notification by sound
char notify_waiting_label[2];   // Placeholder for elipsis label
Boolean notify_flash_step = true;  // Whether we're flashing "!" or " "
int scroll_bottomline = -1;     // Last line displayed by ReloadStats()
int scroll_toprecord = -1;      // Requested DB record for top line of display
int selected_line = -1;         // Selected display line; 0 == top
int edit_record = 999;          // DB record being edited
SndCommandType note1, note2;    // The notes of the notification sound 
program_state state;            // Structure containing state and prefs
int export_type = CTIM_EXPORT_TEXT; // Export human-readable text or CSV?


DWord PilotMain(Word cmd, Ptr cmd_params, Word launchFlags)
{
short err;
EventType evt;
FormType *frm;
Word formID;

    switch (cmd)
    {
    /* Normal Launch */
    case sysAppLaunchCmdNormalLaunch:
        /* Start application */
        StartApplication();

        /* Get events until told to stop */
        do
        {
            EvtGetEvent(&evt, update_rate);
            /* Will the system handle it? */
            if (!SysHandleEvent(&evt)) 
            {
                /* Will the menu handle it? */
                if (!MenuHandleEvent(NULL, &evt, &err))
                {
                    /* Guess I'll have to handle it */
                    if (evt.eType == frmLoadEvent) 
                    {
                        /* Set form handler */
                        formID = evt.data.frmLoad.formID;
                        frm = FrmInitForm(formID);
                        FrmSetActiveForm(frm);
                        switch (formID)
                        {
                        case CTIM_MAIN:
                            FrmSetEventHandler(frm, MainFormHandler);
                            break;
                        case CTIM_EDIT:
                            FrmSetEventHandler(frm, EditFormHandler);
                            break;
                        // --JAM: Add mother info form
                        }
                    }
                    else
                    {
                        /* Let the form handler handle it */
                        FrmDispatchEvent(&evt);
                    }
                }
            }
        } while (evt.eType != appStopEvent);
        StopApplication();
        break;
    /* We don't handle anything else */
    default:
       break;
    }
    return 0;
}

Word StartApplication(void)
{
Err err;
int rcdX = 0;
Boolean found_last = false, user_alerted = false;
contraction_stats tempstats;
        
    // Initialize global variables
    MemSet(&stats, sizeof(stats), 0);
    prevstart = 0;
    notify_waiting_label[0] = 24;    // The ellipsis character
    notify_waiting_label[1] = '\0';  // Null to complete the string
    note1.cmd = sndCmdFreqDurationAmp;
    note1.param1 = 400;
    note1.param2 = 50;
    note1.param3 = sndMaxAmp;
    note2.cmd = sndCmdFreqDurationAmp;
    note2.param1 = 350;
    note2.param2 = 50;
    note2.param3 = sndMaxAmp;
    
    // Pro: was a particular database open last time?
    //   Pro: Load preferences
    //   Pro: Get database name
    //   Pro: If DmFindDatabase(card, name)
    //     Pro: DmOpenDatabase()
    //   Pro: Else
    //     Pro: do the unnamed database stuff below
    
    // Check for a database
    dbStats = DmOpenDatabaseByTypeCreator(CTIM_STATSTYPE, CTIM_ID, dmModeReadWrite);
    if (!dbStats)
    {
        // No database available; create it.
        err = DmCreateDatabase(0, CTIM_STATSNAME, CTIM_ID, CTIM_STATSTYPE, false);
        dbStats = DmOpenDatabaseByTypeCreator(CTIM_STATSTYPE, CTIM_ID, dmModeReadWrite);
        if (!dbStats)
        {
            // Non-fatal error
            FrmCustomAlert(CTIM_RESULTS, "Couldn't save stats.", " ", " ");
        }
    }

    // Load up the last statistic, if interrupted.
    // Also verify the database is in good condition
    // (Why not?  I can.) and set the backup bit.
    if (dbStats)
    {
    LocalID dbID;    // All these are backup bit variables
    UInt16 cardnum;
    UInt16 attr;

        // Set the backup bit
        DmOpenDatabaseInfo(dbStats, &dbID, NULL, NULL, &cardnum, NULL);
        DmDatabaseInfo(cardnum, dbID, NULL, &attr, NULL, NULL,
            NULL, NULL, NULL, NULL, NULL, NULL, NULL);
        attr |= dmHdrAttrBackup;
        DmSetDatabaseInfo(cardnum, dbID, NULL, &attr, NULL, NULL,
            NULL, NULL, NULL, NULL, NULL, NULL, NULL) ;
        // Eliminate invalid records
        for (rcdX = 0; rcdX < DmNumRecords(dbStats); rcdX++)
        {
            LoadStat(rcdX, &tempstats);
            if (tempstats.end_secs == 0)
            {
                // This is an unfinished contraction. 
                // There should be only one per database.
                if (found_last || (tempstats.start_secs == 0))
                {
                    // It's invalid (blank is also invalid).
                    if (!user_alerted)
                    {
                        FrmCustomAlert(CTIM_RESULTS, 
                            "Found invalid data. All invalid records will be deleted.", " ", " ");
                        user_alerted = true;
                    }
                    //--JAM: For interrupted contractions, shouldn't
                    //  the last one be kept, instead of the first?
                    DmRemoveRecord(dbStats, rcdX);
                    rcdX--;  // Because indeces will be modified
                }
                else
                {
                    // Interrupted, but valid; only one per database
                    found_last = true;
                    // Load the data in global stats
                    LoadStat(rcdX, &stats);
                }
            }
        } // Next record, please...
    }

    // Finally, load up the preferences (notably, notification time...)
    // Set up defaults
    MemSet(&state, sizeof(state), 0);
    state.notify_freq = DEFAULT_NOTIFY_FREQ;
    state.notifying = false;
    last_sound_notify = 0;
    last_flash_notify = 0;
    // Load the stats, if they're there
    PrefGetAppPreferencesV10(CTIM_ID, 1, &state, sizeof(state));
    // Set the values
    notify_freq = state.notify_freq;
    notify = state.notifying;
    last_sound_notify = state.last_sound_notify;
    last_flash_notify = state.last_flash_notify;

    // Go to the main form
    FrmGotoForm(CTIM_MAIN);
}

Word StopApplication(void)
{

    // No need to save statistics; they're saved every time a 
    // button gets pressed!  Just close the database.
    if (dbStats)
    {
        DmCloseDatabase(dbStats);
    }

    // Save the new state and prefs
    state.notify_freq = notify_freq;
    state.notifying = notify;
    state.last_sound_notify = last_sound_notify;
    state.last_flash_notify = last_flash_notify;
    PrefSetAppPreferencesV10(CTIM_ID, 1, &state, sizeof(state));
}

Boolean MainFormHandler(EventPtr evt)
{
FormType *form;
Boolean handled = false;
Err err;
int temp;

    // Display form, handle button presses, etc.
    switch (evt->eType)
    {
    case frmOpenEvent:
        // Form is ready to be displayed
        form = FrmGetActiveForm();
        FrmDrawForm(form);
        // Load and Draw the compiled statistics
        if (dbStats)
        {
            // Need to reinitialize display extent?
            if (scroll_toprecord < 0)
            {
                // Set display to show top record
                // Thankfully, database has been validated
                scroll_toprecord = (int)DmNumRecords(dbStats) - 4;
                // toprecord will be validated by ReloadStats()
            }
        }
        else
        {
            // If you're not keeping records, you only get one line
            scroll_toprecord = 0;
        }
        ReloadStats();
        // After return from another form, the row is unhighlighted!
        if ((selected_line >= 0) && (selected_line < 4))
        {
            temp = selected_line;
            selected_line = -1;
            HighlightRow(temp);  // Rehighlight row
        }
        // Start the elapsed time counter if appropriate
        // (Fixes stop if exited program and returned during contraction)
        if (notify || ((stats.start_secs != 0) && (stats.end_secs == 0)))
        {
            update_rate = COUNTER_UPDATE_RATE;
        }
        // Make the notification indicator read properly
        UpdateNotificationIndicator();
        handled = true;
        break;
    case nilEvent:
        // We must be in a contraction or notifying
        // Update the elapsed counter (only works if we're in a contraction)
        UpdateCounter();
        // If notifying, flash indicator and maybe play sound
        Notify();
        handled = true;
        break;
    case ctlSelectEvent:
    case ctlRepeatEvent:
        // Someone pressed a button!  (Maybe a repeat button, I don't care.)
        switch (evt->data.ctlSelect.controlID)
        {
        case CTIM_BTNSTART:
            // Start the contraction
            if (stats.start_secs != 0)
            {
                // User pressed start button while current contraction
                // still going; assume he wants to end the current contraction
                stats.end_secs = TimGetSeconds();
                // Update the stats
                if (dbStats)
                {
                    // Remove interrupted record first
                    if (DmNumRecords(dbStats))
                    {
                        // Don't delete the note!
                        temp = DmNumRecords(dbStats) - 1;
                        MemSet(note, sizeof(note), 0);
                        LoadNote(temp, note);
                        DmRemoveRecord(dbStats, temp);
                    }
                    WriteStats();
                    if (StrLen(note) > 0)
                    {
                        // There was a note
                        WriteNote(temp, note);
                    }
                }
                // Set up for next contraction
                prevstart = stats.start_secs;
                MemSet(&stats, sizeof(stats), 0);
                // Start the new contraction
            }
            stats.start_secs = TimGetSeconds();
            stats.end_secs = 0;  // Should be memzeroed already
            // Give feedback for pressing start button
            WriteStats();
            // Start the elapsed time counter
            update_rate = COUNTER_UPDATE_RATE;
            // Notify if frequency faster than specified, and it's not the
            // first contraction (which always uses frequency 0:00)
            // (Watch out for that arithmetic; these are actually UINT32s,
            // but I've got them defined as longs.  Bad on the > 0 check.)
            if (((stats.start_secs - prevstart) < notify_freq)  &&
                (prevstart != 0))
            {
                // Start notification
                notify = true;
                // Set notification timeout
                last_sound_notify = stats.start_secs - NOTIFY_SOUND_TIMEOUT - 1;
                last_flash_notify = stats.start_secs - NOTIFY_FLASH_TIMEOUT - 1;
                // Give first notification (resets notification timeout)
                Notify();
            }
            // Scroll if necessary
            if (dbStats)
            {
                // Try to make this the top record
                // (ReloadStats() will validate it and set prevstart correctly)
                scroll_toprecord = (int)DmNumRecords(dbStats) - 1;
            }
            ReloadStats();
            HighlightRow(scroll_bottomline);
            handled = true;
            break;
        case CTIM_BTNEND:
            // End the contraction
            if (stats.start_secs == 0)
            {
                // Crazy idiot.  Nothing is happenning already.
                FrmCustomAlert(CTIM_RESULTS, "No contraction started.", " ", " ");
                // --JAM: perhaps I should disable the "end" button
            }
            else
            {
                // End the contraction
                stats.end_secs = TimGetSeconds();
                // Stop the update timer, but leave counter running if
                // we're still notifying about frequency achieved
                if (!notify)
                {
                   update_rate = evtWaitForever;
                }
                ChangeLabel(CTIM_BTNELAPSED, " ");
                // Update the stats
                if (dbStats)
                {
                    // Remove interrupted record first
                    if (DmNumRecords(dbStats))
                    {
                        // Can't imagine when this wouldn't be the case
                        temp = DmNumRecords(dbStats) - 1;
                        MemSet(note, sizeof(note), 0);
                        LoadNote(temp, note);
                        DmRemoveRecord(dbStats, temp);
                    }
                    WriteStats();  // Appends a record
                    if (StrLen(note) > 0)
                    {
                        // Write the note, too
                        WriteNote(temp, note);  // Overwrites stats.log_len
                    }
                    // Scroll this record to top, if possible
                    scroll_toprecord = temp;
                }
                // ReloadStats() will display this record, and reset prevstart
                ReloadStats();
                HighlightRow(scroll_bottomline);
                // Set up for next contraction
                prevstart = stats.start_secs;
                MemSet(&stats, sizeof(stats), 0);
            }
            handled = true;
            break;
        case CTIM_BTNUP:
            Scroll_Up();
            handled = false;  // Let the CtlHandleEvent handle repeating
            break;
        case CTIM_BTNDN:
            Scroll_Down();
            handled = false;  // Let the CtlHandleEvent handle repeating
            break;
        case CTIM_BTNEDIT:
            // Go to the editing form
            if (dbStats)
            {
                if ((selected_line >= 0) && (selected_line < 4))
                {
                    // A line is selected
                    if (selected_line <= scroll_bottomline)
                    {
                        edit_record = selected_line + scroll_toprecord;
                        FrmGotoForm(CTIM_EDIT);
                    }
                    else
                    {
                        FrmCustomAlert(CTIM_RESULTS, "Invalid record selected.", " ", " ");
                    }
                }
                else
                {
                    // No line is selected
                    if (stats.start_secs != 0)
                    {
                        // Add to occurring event
                        edit_record = (int)DmNumRecords(dbStats) - 1;
                    }
                    else
                    {
                        // No contraction; this is solely a log entry
                        edit_record = -1; // Create a new record
                    }
                    FrmGotoForm(CTIM_EDIT);
                }
            }  // dbStats: don't record comments without it!
            else
            {
                FrmCustomAlert(CTIM_RESULTS, "Can't record comments without database!", " ", " ");
            }
            handled = true;
            break;
        // Highlight whole lines when one button is clicked
        case CTIM_PSHSTART1:
        case CTIM_PSHFREQ1:
        case CTIM_PSHLEN1:
        case CTIM_PSHNOTE1:
            HighlightRow(0);
            handled = true;
            break;
        case CTIM_PSHSTART2:
        case CTIM_PSHFREQ2:
        case CTIM_PSHLEN2:
        case CTIM_PSHNOTE2:
            HighlightRow(1);
            handled = true;
            break;
        case CTIM_PSHSTART3:
        case CTIM_PSHFREQ3:
        case CTIM_PSHLEN3:
        case CTIM_PSHNOTE3:
            HighlightRow(2);
            handled = true;
            break;
        case CTIM_PSHSTART4:
        case CTIM_PSHFREQ4:
        case CTIM_PSHLEN4:
        case CTIM_PSHNOTE4:
            HighlightRow(3);
            handled = true;
            break;
        case CTIM_BTNNOTIFY:
            // Toggle notification status:
            // A slightly more complex than expected maneuver, since the
            // user may want to disable notification before notification
            // has begun.  The two are distinguishable by their notify_freq;
            // it's 0 if notification is disabled, something else if not.
            if (notify || (notify_freq != 0))
            {
                // The user wants no notifications
                notify = false;
                notify_freq = 0;
                // Stop the timer if we're not in a contraction
                if (stats.start_secs == 0)
                {
                    update_rate = evtWaitForever;
                }
            }
            else
            {
                // User would like to recieve notifications when appropriate
                notify_freq = DEFAULT_NOTIFY_FREQ;
            }
            // Hmmm, hmmm... what if he asks for notification, and
            // a qualifying contraction has just begun?  Better reset
            // the notification variables.  But then, what if he's turning
            // it off, but wants to be notified next time?  Hmmm, hmmm...
            // He's an idiot if he can't check the frequency of the last
            // contraction when he asks for notifications (how did he get
            // to be a coach, anyway?).  Don't check for notification here.
            UpdateNotificationIndicator();
            handled = true;
            break;
        default:
            handled = false;
        }
        // Update the counter when any button is pressed
        UpdateCounter();
        break;
    case menuEvent:
        switch (evt->data.menu.itemID)
        {
        case CTIM_MENUCLEARSTATS:
            // Delete the database and clear the display
            if (scroll_bottomline >= 0)
            {
                // There are records to delete
                if (!FrmCustomAlert(CTIM_CONFIRM, 
                    "You are about to delete the log!", "Proceed?", " "))
                {
                    // The user really wants to delete
                    if (dbStats)
                    {
                        // Delete each record
                        while (DmNumRecords(dbStats))
                        {
                            // Delete first record
                            DmRemoveRecord(dbStats, 0);
                        }
                    }
                    // Set stats to 0
                    MemSet(&stats, sizeof(stats), 0);
                    prevstart = 0;
                    // Clear the display
                    ClearStats();
                    // Stop notifying
                    if (notify)
                    {
                        notify = false;
                        UpdateNotificationIndicator();
                    }
                    // No more display to worry about
                    scroll_bottomline = -1;
                }
            }
            else
            {
                // Let him know he's done something...
                FrmCustomAlert(CTIM_RESULTS, "No entries to delete.", " ", " ");
            }
            handled = true;
            break;
        case CTIM_MENUDELONE:
            // Remove this record from the database,
            // reload, and display everything
            if ((selected_line >= 0) && (selected_line <= 4))
            {
                if (dbStats)
                {
                    if ((scroll_toprecord >= 0) &&
                        (scroll_toprecord + selected_line) < DmNumRecords(dbStats))
                    {
                        // It is valid to delete this line
                        if (!FrmCustomAlert(CTIM_CONFIRM, 
                            "You are about to delete an entry!", 
                            "Proceed?", " "))
                        {
                            // The user really wants to
                            if ((scroll_toprecord + selected_line) == (DmNumRecords(dbStats) - 1))
                            {
                                // He's deleting the last contraction.  It
                                // could be ongoing; zero the stats (if 
                                // they're not already) to avoid confusion
                                // with an interrupted contraction.
                                MemSet(&stats, sizeof(stats), 0);
                            }
                            DmRemoveRecord(dbStats, 
                                scroll_toprecord + selected_line);
                            ReloadStats();
                        }
                    }
                    else
                    {
                        FrmCustomAlert(CTIM_RESULTS, 
                            "Invalid entry selected.", " ", " ");

                    }
                }
                else
                {
                    // No database to delete from
                    // --JAM: delete current contraction?  How would I know
                    // the start time of previous for freq calculations?
                    FrmCustomAlert(CTIM_RESULTS, 
                        "No records available.", " ", " ");
                }
            }
            else
            {
                FrmCustomAlert(CTIM_RESULTS, "No entry selected.", " ", " ");
            }
            handled = true;
            break;
        case CTIM_MENUEXPORT:
            // Export stats to MemoPad in human-readable format
	    export_type = CTIM_EXPORT_TEXT;
	    ExportToMemoPad();
	    handled = true;
	    break;
	case CTIM_MENUEXPORTCSV:
	    // Export CSV to MemoPad
	    export_type = CTIM_EXPORT_CSV;
	    ExportToMemoPad();
	    handled = true;
	    break;
        case CTIM_MENUABOUT:
            // Display program information
            FrmHelp(CTIM_HELPABOUT);
        default: 
            handled = false;
        }
    case keyDownEvent:
       if ((evt->data.keyDown.modifiers & commandKeyMask)) 
       {
           // This is a (Reference-approved) virtual character.
           switch (evt->data.keyDown.chr)
           {
           case vchrPageUp:
               Scroll_Up();
               handled = true;
               break;
           case vchrPageDown:
               Scroll_Down();
               handled = true;
               break;
           default:
               handled = false;
           }
       }
    default:
        handled = false;
    }
    return handled;
}

// It is the responsibility of the caller to make certain that edit_record
// points to a valid record, or -1 for a new record
Boolean EditFormHandler(EventPtr evt)
{
FormType *form;
Boolean handled = false;
FieldPtr pFld;
Boolean new_record = false;
contraction_stats tempstats;
long freqstart;

char *start_str = "Start: ";
char *end_str = "End: ";
char *len_str = "Len: ";
char *freq_str = "Freq: ";
char *log_str = "Event at: ";
char label_str[60];
Coord start_x = 5;
Coord start_y = 20;
Coord end_x = 13;
Coord end_y = start_y + 10;
Coord freq_x = 9;
Coord freq_y = end_y + 10;
Coord len_x = 12;
Coord len_y = freq_y + 10;

    // Display form, handle button presses, etc.
    switch (evt->eType)
    {
    case frmOpenEvent:
        // Form is ready to be displayed
        form = FrmGetActiveForm();
        // Load and Draw the current comment
        if (dbStats)
        {
            // The database exists
            // Should we create a new record, or edit an existing one?
            if (edit_record < 0)
            {
                // Create a new record at current time
                // Save global stats
                MemMove(&tempstats, &stats, sizeof(stats));
                // Make & save new record data
                stats.start_secs = TimGetSeconds();
                stats.end_secs = stats.start_secs;
                stats.log_len = 0;
                WriteStats();
                // Restore global stats
                MemMove(&stats, &tempstats, sizeof(stats));
                // Set new record indicator
                new_record = true;
                // Set edit_record index
                edit_record = (int)DmNumRecords(dbStats) - 1;
            }
            else if (edit_record < DmNumRecords(dbStats))
            {
                // It is a valid record line; load the note
                MemSet(&note, sizeof(note), 0);
                LoadNote(edit_record, note);
                // Set it into the field
                pFld = FrmGetObjectPtr(form, 
                    FrmGetObjectIndex(form, CTIM_FLDCOMMENT));
                FldInsert(pFld, note, StrLen(note));
            }
            else
            {
                FrmCustomAlert(CTIM_RESULTS, "Invalid record to edit?", " ", " ");
                FrmGotoForm(CTIM_MAIN);
            }
        }
        // Set the focus to the form
        FrmDrawForm(form);
        FrmSetFocus(form, FrmGetObjectIndex(form, CTIM_FLDCOMMENT));
        // Draw the event details strings
        LoadStat(edit_record, &tempstats);
        if (tempstats.start_secs == tempstats.end_secs)
        {
            // It's a log; draw only the log time
            label_str[0] = '\0';
            StrCat(label_str, log_str);
            SecsToFullDateTime(tempstats.start_secs, label_str);
            WinDrawChars(label_str, StrLen(label_str), start_x, start_y);
        }
        else
        {
            // It's an event; draw the start, end, frequency, and duration
            // Start
            label_str[0] = '\0';
            StrCat(label_str, start_str);
            SecsToFullDateTime(tempstats.start_secs, label_str);
            WinDrawChars(label_str, StrLen(label_str), start_x, start_y);
            // End
            label_str[0] = '\0';
            StrCat(label_str, end_str);
            // We could be in the middle of an event!
            if (tempstats.end_secs != 0)
            {
                SecsToFullDateTime(tempstats.end_secs, label_str);
            }
            else
            {
                StrCat(label_str, "Event In Progress");
            }
            WinDrawChars(label_str, StrLen(label_str), end_x, end_y);
            // Frequency
            label_str[0] = '\0';
            StrCat(label_str, freq_str);
            freqstart = PreviousStartSecs(edit_record);
            // We could be detailing the first event!
            if (freqstart != 0)
            {
                SecsToDuration(tempstats.start_secs - freqstart, label_str);
            }
            else
            {
                StrCat(label_str, "First Event");
            }
            WinDrawChars(label_str, StrLen(label_str), freq_x, freq_y);
            // Duration
            label_str[0] = '\0';
            StrCat(label_str, len_str);
            // We could be in the middle of an event!
            if (tempstats.end_secs != 0)
            {
                SecsToDuration(tempstats.end_secs - tempstats.start_secs, label_str);
            }
            else
            {
                StrCat(label_str, "Event In Progress");
            }
            WinDrawChars(label_str, StrLen(label_str), len_x, len_y);
        }
        handled = true;
        break;
    case ctlSelectEvent:
        // Someone pressed a button!
        switch (evt->data.ctlSelect.controlID)
        {
        // Pro: Extra buttons and drop-downs, like dilate/efface/station
        case CTIM_BTNOK:
            // Copy from field to note buffer
            form = FrmGetActiveForm();
            pFld = FrmGetObjectPtr(form, 
                FrmGetObjectIndex(form, CTIM_FLDCOMMENT));
            MemSet(&note, sizeof(note), 0);
            if (FldGetTextPtr(pFld) != NULL)
            {
                StrCopy(note, FldGetTextPtr(pFld));
            }
            // Add the note to the record
            if (new_record)
            {
                // We created this record
                if (StrLen(note) == 0)
                {
                    // Note is invalid; delete the whole entry
                    DmRemoveRecord(dbStats, edit_record);
                }
                else
                {
                    // Note is valid; attach the note
                    WriteNote(edit_record, note);
                    // Scroll to the note
                    scroll_toprecord = edit_record;
                }
            }
            else
            {
                // This was an existing record; attach the note
                WriteNote(edit_record, note);
            }
            // Return to the main form
            FrmGotoForm(CTIM_MAIN);
            handled = true;
            break;
        case CTIM_BTNCANCEL:
            // Don't add the comment
            if (edit_record < 0)
            {
                // We created this record; we don't want it any more
                DmRemoveRecord(dbStats, (int)DmNumRecords(dbStats) - 1);
            }
            FrmGotoForm(CTIM_MAIN);
            handled = true;
            break;
        default:
            // How did we get here?
            handled = false;
        }
    case menuEvent:
        form = FrmGetActiveForm();
        pFld = FrmGetObjectPtr(form, 
            FrmGetObjectIndex(form, CTIM_FLDCOMMENT));
        switch (evt->data.menu.itemID)
        {
        case CTIM_MENUCUT:
            // Copy the selected text, if any, and then delete it
            if (pFld)
            {
                // Why wouldn't it be here?  I'm just paranoid.
                FldCut(pFld);
            }
            handled = true;
            break;
        case CTIM_MENUCOPY:http://www.flipcode.com/interviews/earthlight/
            // Copy the selected text
            if (pFld)
            {
                FldCopy(pFld);
            }
            handled = true;
            break;
        case CTIM_MENUPASTE:
            // Paste text into field
            if (pFld)
            {
                FldPaste(pFld);
            }
            handled = true;
            break;
        // Pro: extra events, like Pitosin, voiding, etc...
        default: 
            handled = false;
        }
/*  Maybe we should scroll the field?
    case keyDownEvent:
       if ((evt->data.keyDown.modifiers & commandKeyMask)) 
       {
           // This is a (Reference-approved) virtual character.
           switch (evt->data.keyDown.chr)
           {
           case vchrPageUp:
               Scroll_Up();
               handled = true;
               break;
           case vchrPageDown:
               Scroll_Down();
               handled = true;
               break;
           default:
               handled = false;
           }
       }
*/
    default:
        handled = false;
    }
    return handled;
}

int WriteStats(void)
{
VoidHand rcdH;
VoidPtr rcdP;
UInt rcdX = dmMaxRecordIndex;

    if (!dbStats)
    {
        return(false);
    }
    // Write the stats
    rcdH = DmNewRecord(dbStats, &rcdX, sizeof(stats));
    if (rcdH)
    {
        rcdP = MemHandleLock(rcdH);
        DmWrite(rcdP, 0, &stats, sizeof(stats));
        MemHandleUnlock(rcdH);
        DmReleaseRecord(dbStats, rcdX, true);
        return(true);
    }
    else 
    {
        FrmCustomAlert(CTIM_RESULTS, "Couldn't save entry!", " ", " ");
        return(false);
    }
}

// Appends or removes a note to a contraction log entry
int WriteNote(int rcdX, char *notebuf)
{
VoidHand rcdH;
VoidPtr rcdP;
contraction_stats tempstats;

    if (!dbStats)
    {
        return(false);
    }
    // Change the record size to accomodate new note size
    rcdH = DmResizeRecord(dbStats, rcdX, sizeof(stats) + StrLen(notebuf));
    if (rcdH)
    {
        // Read, modify, & write the stats
        rcdP = MemHandleLock(rcdH);
        // Update the stats to include the note length
        MemSet(&tempstats, sizeof(tempstats), 0);
        MemMove(&tempstats, rcdP, sizeof(tempstats));
        if (notebuf != NULL)
        {
            tempstats.log_len = StrLen(notebuf);
        }
        else
        {
            tempstats.log_len = 0;
        }
        DmWrite(rcdP, 0, &tempstats, sizeof(tempstats));
        // Now tack on the note, if any
        if (tempstats.log_len > 0)
        {
            // --JAM: Changed since 2.12.0.  Minor, but if something bombs...
            // DmWrite(rcdP, sizeof(stats), notebuf, tempstats.log_len);
            DmWrite(rcdP, sizeof(tempstats), notebuf, tempstats.log_len);
        }
        MemHandleUnlock(rcdH);
        DmReleaseRecord(dbStats, rcdX, true);
        return(true);
    }
    else 
    {
        FrmCustomAlert(CTIM_RESULTS, "Couldn't save note!", " ", " ");
        return(false);
    }
}
//--JAM: int WriteEvents(int rcdx, char *events);
//This would add events to the record.  Events would be a structure with
//a size; I could compare sizeof(contraction_stats) + stats.log_len to
//MemHandleSize(DmGetRecord()) to determine whether or not any events 
//had already been written.

void ChangeLabel(int button_id, char *new_label)
{
ControlType *pcontrol;
FormType *form;

    form = FrmGetActiveForm();
    pcontrol = FrmGetObjectPtr(form, FrmGetObjectIndex(form, button_id));
    CtlSetLabel(pcontrol, new_label); 
}

/*
 * It converts the seconds to a years/days/hours/minutes/seconds format,
 * using no more than 5 characters: up to 2 digits of major time, a separator,
 * and 2 digits of minor time. Note that days could go to 3 digits; in this
 * case, a separator will be printed, but no hours.
 *
 */
void SecsTo5Chars(long seconds, char *str)
{
int half1 = 0;
int half2 = 0;
char *sep1;
char *sep2;
char buf[10];
char timestr[8]; // More than enough to hold the 5 chars
#define DISPLAY_CHARS 5
#define YEARSECS 30758400
#define DAYSECS 86400
#define HOURSECS 3600
#define MINSECS 60

    // Lots of comparisons, but very few computations.
    
    // Set up the local string
    timestr[0] = '\0';

    //  Find out which two fields we should try
    if (seconds > YEARSECS)
    {
        half1 = seconds / YEARSECS;
        half2 = (seconds % YEARSECS) / DAYSECS;
        sep1 = "y";
        sep2 = "d";
    }
    else if (seconds > DAYSECS)
    {
        half1 = seconds / DAYSECS;
        half2 = (seconds % DAYSECS) / HOURSECS;
        sep1 = "d";
        sep2 = "h";
    }
    else if (seconds > HOURSECS)
    {
        half1 = seconds / HOURSECS;
        half2 = (seconds % HOURSECS) / MINSECS;
        sep1 = "h";
        sep2 = NULL;
    }
    else
    {
        half1 = seconds / MINSECS;
        half2 = seconds % MINSECS;  // (...)/SECSECS? ;)
        sep1 = ":";
        sep2 = NULL;
    }

    // Now put them into the string
    //
    // Start with the first half and its separator
    if ((seconds < HOURSECS) && (half1 < 10))
    {
        StrCat(str, "0");
    }
    StrIToA(buf, half1);
    StrCat(timestr, buf);
    StrCat(timestr, sep1);

    // Calculate the length of the second half
    StrIToA(buf, half2);
    half1 = StrLen(buf);    // Now we can reuse "half1" as a length variable
    if (half2 < 10)
    {
        half1++;
    }
    // Can we fit the second half in?
    half1 = StrLen(timestr) + half1;
    if (half1 <= DISPLAY_CHARS)
    {
        if (half2 < 10)
        {
            StrCat(timestr, "0");
        }
        StrCat(timestr, buf);
        // How about an extra separator?  Will that fit?
        if ((half1 < DISPLAY_CHARS) && sep2)
        {
            StrCat(timestr, sep2);
        }
    }

    // The local string contains the time.  Stick it on the passed string.
    StrCat(str, timestr);
}

void SecsToDuration(long seconds, char *str)
{
char buf[10];
char timestr[50]; 
long remainder;
#define YEARSECS 30758400
#define DAYSECS 86400
#define HOURSECS 3600
#define MINSECS 60

    // Set up the local string
    timestr[0] = '\0';

    // Now put them into the string
    remainder = seconds;
    if (remainder > YEARSECS)
    {
        StrIToA(buf, remainder / YEARSECS);
        StrCat(timestr, buf);
        StrCat(timestr, "y, ");
        remainder = remainder % YEARSECS;
    }
    if ((seconds > YEARSECS) || (remainder > DAYSECS))
    {
        StrIToA(buf, remainder / DAYSECS);  // Could be 0
        StrCat(timestr, buf);
        StrCat(timestr, "d, ");
        remainder = remainder % DAYSECS;
    }
    if ((seconds > DAYSECS) || (remainder > HOURSECS))
    {
        StrIToA(buf, remainder / HOURSECS);  // Could be 0
        StrCat(timestr, buf);
        StrCat(timestr, "h, ");
        remainder = remainder % HOURSECS;
    }
    // Finally, hours and minutes
    StrIToA(buf, remainder / MINSECS);
    if (StrLen(buf) < 2)  // buf will always have at least 1 char: "0"
    {
       StrCat(timestr, "0");
    }
    StrCat(timestr, buf);
    StrCat(timestr, ":");
    remainder = remainder % MINSECS;
    StrIToA(buf, remainder);
    if (StrLen(buf) < 2)
    {
        StrCat(timestr, "0");
    }
    StrCat(timestr, buf);
    
    // The local string contains the time.  Stick it on the passed string.
    StrCat(str, timestr);
}

void SecsToFullDateTime(long seconds, char *str)
{
DateTimeType datetime;
char buf[10];
char datestr[dowLongDateStrLength];     // DateTime.h: "weekday, month day, year" (25 chars)
char timestr[timeStringLength + 4];     // Four extra characters for seconds
char ampm[4];
DateFormatType format = dfMDYLongWithComma; // Might change with sys prefs someday
long ndx;
   
    // Let the system figure out the date/time
    TimSecondsToDateTime((UInt32)seconds, &datetime);
    // Convert that DateTimeType structure to nice ASCII strings
    // Starting with date
    DateToDOWDMFormat(datetime.month, datetime.day, datetime.year, format, datestr);
    // Now time; use hh:mm:ss a|pm instead of stupid system without secs
    TimeToAscii(datetime.hour, datetime.minute, tfColonAMPM, timestr);
    // Strip the am/pm
    ndx = StrLen(timestr) - 3;
    ampm[0] = timestr[ndx++];
    ampm[1] = timestr[ndx++];
    ampm[2] = timestr[ndx++];
    ampm[3] = '\0';
    // Add the seconds
    timestr[StrLen(timestr) - 3] = '\0';
    StrCat(timestr, ":");
    StrIToA(buf, datetime.second);
    if (datetime.second < 10)
    {
        StrCat(timestr, "0");
    }
    StrCat(timestr, buf);
    // Now add the am/pm back on
    StrCat(timestr, ampm);
    // Cat the date and time onto the passed string
    StrCat(str, datestr);
    StrCat(str, " ");
    StrCat(str, timestr);
}
// Reload and redisplay stats
void ReloadStats()
{
int rcdX = 0;
Boolean found_last = false;
contraction_stats tempstats;
DateTimeType time;
char num[20];
int row = 0, line = 0;
int x;

    // This is much more complicated than it needs to be so 
    // I don't use 2.0 functions like StrPrintF or tables

    // What do I do if there's no database?
    if (!dbStats)
    {
        return;
    }
    
    // Clear the stats out
    ClearStats();
    
    // Must validate display extent
    if (scroll_toprecord > ((int)DmNumRecords(dbStats) - 4))
    {
        // Won't be enough records to display to bottom
        scroll_toprecord = ((int)DmNumRecords(dbStats) - 4);
    }
    if (scroll_toprecord < 0)
    {
        // Could have been passed this way, could be from above
        scroll_toprecord = 0;
    }

    // Find the start of the event previous to scroll_toprecord
    prevstart = PreviousStartSecs(scroll_toprecord);
    
    // Now display up to four records
    rcdX = scroll_toprecord;
    found_last = false;
    scroll_bottomline = -1;
    for (line = 0; line < 4; line++)
    {
        // Don't try to load invalid records!
        if (rcdX < DmNumRecords(dbStats))
        { 
            LoadStat(rcdX, &tempstats);
            
            // Display it in row <line>
            row = line * 4;
            scroll_bottomline = line;

            // Add start time in hh:mm format
            MemSet(&time, sizeof(time), 0);
            TimSecondsToDateTime(tempstats.start_secs, &time);
            MemSet(num, sizeof(num), 0);
            TimeToAscii(time.hour, time.minute, true, num);
            DynamicStrCopy(&ButtonTexts[row + 0], num);
            ChangeLabel(row + CTIM_PSHSTART1, ButtonTexts[row + 0]);

            // Add frequency in mm:ss format
            MemSet(num, sizeof(num), 0);
            if (tempstats.end_secs == tempstats.start_secs)
            {
                // This is a log entry
                StrCopy(num, "Log");
            }
            else
            {
                // This is a contraction of some sort
                if (prevstart == 0)
                {
                    // This is the first contraction; set frequency to 0
                    SecsTo5Chars(0, num);
                }
                else
                {
                    // A frequency calculation is possible
                    SecsTo5Chars(tempstats.start_secs - prevstart, num);
                }
            }
            DynamicStrCopy(&ButtonTexts[row + 1], num);
            ChangeLabel(row + CTIM_PSHFREQ1, ButtonTexts[row + 1]);

            // Add length/duration in mm:ss format
            if (tempstats.end_secs != 0)
            {
                // This is not an interrupted contraction
                if (tempstats.end_secs == tempstats.start_secs)
                {
                    // This is a log only
                    StrCopy(num, "Entry");
                }
                else
                {
                    // This is a contraction
                    MemSet(num, sizeof(num), 0);
                    SecsTo5Chars(tempstats.end_secs - tempstats.start_secs, num);
                }
            }
            else
            {
                // This is interrupted (or start button feedback)
                StrCopy(num, "--:--");
            }
            DynamicStrCopy(&ButtonTexts[row + 2], num);
            ChangeLabel(row + CTIM_PSHLEN1, ButtonTexts[row + 2]);

            // Add note (if any)
            StrCopy(num, " ");
            if (tempstats.log_len > 0)
            {
                MemSet(note, sizeof(note), 0);
                LoadNote(rcdX, note);
                // Truncate note to button size
                x = 1;
                while ((x <= StrLen(note)) && 
                       (FntCharsWidth(note, x) < (NOTEPIXELS)))
                {
                    x++;
                } 
                // Can't use StrNCopy; it's 2.0.  This simple algorythm
                // doesn't account for multi-byte or anything
                if (x >= 0)
                {
                    num[x] = '\0';
                }
                while (x > 0)
                {
                    num[--x] = note[x];
                }
            }
            // Copy the note into the label area
            DynamicStrCopy(&ButtonTexts[row + 3], num);
            ChangeLabel(row + CTIM_PSHNOTE1, ButtonTexts[row + 3]);

            // Set up for next record
            if (tempstats.start_secs != tempstats.end_secs)
            {
                // Only for actual events, not log entries
                prevstart = tempstats.start_secs;
            }
            rcdX++;

            // Increment to next display line (in for loop)
        }
        // May do extra loops (up to four) if out of records.
    }
    
    // Up to four lines have been displayed; we're done!
}

void ClearStats(void)
{
UInt field;

    for (field = 0; field < 16; field++)
    {
        ChangeLabel(CTIM_PSHSTART1+field, " ");
    }
}

void DynamicStrCopy(char **dest, char *src)
{
    if (*dest)
    {
        MemPtrFree(*dest);
    }
    *dest = MemPtrNew(StrLen(src) + 1);
    StrCopy(*dest, src);
}

void HighlightRow(int the_row)
{
FormType *form;
int n;

    form = FrmGetActiveForm();
    // Turn off previously selected row, if any
    if ((selected_line >= 0) && (selected_line < 4))
    {
        for (n = 0; n < 4; n++)
        {
            CtlSetValue(
                FrmGetObjectPtr(form, FrmGetObjectIndex(form, 
                CTIM_PSHSTART1 + (selected_line * 4) + n)), 0);
        }
    }
    // Turn on desired row if it was not already on
    if (selected_line != the_row) 
    {
        // Turn on the selected row
        for (n = CTIM_PSHSTART1; n <= CTIM_PSHNOTE1; n++)
        {
            CtlSetValue(
                FrmGetObjectPtr(form, FrmGetObjectIndex(form, 
                (the_row * 4) + n)), 1);
        }
        selected_line = the_row;
    }
    else
    {
        // Desired row was turned off, above
        selected_line = -1;
    }
}

void LoadStat(int index, contraction_stats *cs)
{
VoidHand rcdH;
VoidPtr rcdP;

    MemSet(cs, sizeof(contraction_stats), 0);
    cs->start_secs = 0;
    cs->end_secs = 0;
    rcdH = DmGetRecord(dbStats, index);
    if (rcdH)
    {
        rcdP = MemHandleLock(rcdH);
        MemMove(cs, rcdP, sizeof(contraction_stats));
        MemHandleUnlock(rcdH);
        DmReleaseRecord(dbStats, index, true);
    }
}

void LoadNote(int index, char *buf)
{
VoidHand rcdH;
VoidPtr rcdP;

    rcdH = DmGetRecord(dbStats, index);
    if (rcdH)
    {
        rcdP = MemHandleLock(rcdH);
        MemMove(buf, rcdP + sizeof(contraction_stats), 
           ((contraction_stats *)rcdP)->log_len);
        MemHandleUnlock(rcdH);
        DmReleaseRecord(dbStats, index, true);
    }
}

void Scroll_Up(void)
{
    if (selected_line < 0)
    {
       HighlightRow(0);  // Gives extra feedback
    }
    if (selected_line > 0)
    {
        // Move only the highlight
        HighlightRow(selected_line - 1);
    }
    else if (scroll_toprecord > 0)
    {
       scroll_toprecord--;
       ReloadStats();
    }
}

void Scroll_Down(void)
{
    if (selected_line < 0)
    {
       HighlightRow(scroll_bottomline);  // Gives extra feedback
    }
    if ((selected_line < scroll_bottomline) && (selected_line < 3))
    {
        // Move only the highlight
        HighlightRow(selected_line + 1);
    }
    else 
    {
        if (dbStats)
        {
            // Need at least 5 records to scroll down
            if ((DmNumRecords(dbStats) > 4) &&
                (scroll_toprecord < ((int)DmNumRecords(dbStats) - 4)))
            {
                scroll_toprecord++;
                ReloadStats();
            }
        }
    }
}

void ExportToMemoPad()
{
DmOpenRef dbMemo;        
DateTimeType time;
int rcdX;        
VoidHand rcdH;
char *buf;
VoidHand bufH;
Err err;
char num[50];
contraction_stats tempstats;
long tempprev = 0;
char *header = "Start\tFreq \tLength\n";
char *separator = "\t";
char *log_separator = "\n";
char *end_separator = "\n\n";
char *empty_end_separator = "\n";
char *lognote = "Log Entry:\n";
char *notime = "--:-- ";
#define NO_NAME ""
UInt32 prevsize;
UInt32 maxsize = 4000;  //Assumed MemoPad limit, with allowance for extra
int fragment = 1;
    
    // Set up for conversion type
    if (export_type == CTIM_EXPORT_CSV)
    {
      header = "Start,Freq,Length,Comment\n";
      separator = ",";
      // Magic!  Enclose comment in quotes, easily!
      log_separator = ",\"";
      end_separator = "\"\n";
      empty_end_separator = "\"\n";
      lognote = "";
      notime = "00:00";
    }
    // Check for database available
    dbMemo = DmOpenDatabaseByTypeCreator('DATA', sysFileCMemo, dmModeReadWrite);
    if (!dbMemo)
    {
        // No database available.
        FrmCustomAlert(CTIM_RESULTS, "Couldn't open MemoPad database!", " ", " ");
        return;
    }

    // Create a new buffer suitable for a Memo
    buf = InitMemo(dbMemo, &bufH, NO_NAME, fragment);
    if (!buf)
    {
        // Can't create a new Memo; exit with error alert
        FrmCustomAlert(CTIM_RESULTS, "Not enough memory to create a memo", " ", " ");
        if (bufH)
        {
            MemHandleFree(bufH);
        }
        return;
    }

    // Add the column headers (for first record only)
    MemHandleUnlock(bufH);
    err = MemHandleResize(bufH, MemHandleSize(bufH) + StrLen(header));
    if (!err)
    {
        buf = MemHandleLock(bufH);
        StrCat(buf, header);
        MemHandleUnlock(bufH);
    }
    else
    {
        MemHandleFree(bufH);
        FrmCustomAlert(CTIM_RESULTS, "Not enough memory to create a memo", " ", " ");
        return;
    }

    //
    // Add on data, keeping track of size before each record
    //
    for (rcdX = 0; rcdX < DmNumRecords(dbStats); rcdX++)
    {
        // Record the start of the record, just in case we have to back up
        prevsize = MemHandleSize(bufH);

        // Get the vital statistics from this record
        LoadStat(rcdX, &tempstats);
        
        // Add start time in hh:mm format
        MemSet(&time, sizeof(time), 0);
        TimSecondsToDateTime(tempstats.start_secs, &time);
        MemSet(num, sizeof(num), 0);
        TimeToAscii(time.hour, time.minute, true, num);
        err = MemHandleResize(
                bufH, 
                MemHandleSize(bufH) + StrLen(num) + StrLen(separator));
        if (!err)
        {
            buf = MemHandleLock(bufH);
            StrCat(buf, num);
            StrCat(buf, separator);
            MemHandleUnlock(bufH);
        }

        // Add frequency in mm:ss format
	// 
	// Check for logs
        if (tempstats.start_secs == tempstats.end_secs)
        {
            // A log entry
	    if (export_type == CTIM_EXPORT_CSV)
	    {
	      err = MemHandleResize(bufH, MemHandleSize(bufH) + StrLen(lognote) + StrLen(",,"));
	    }
	    else
	    {
	      err = MemHandleResize(bufH, MemHandleSize(bufH) + StrLen(lognote));
	    }
            if (!err)
            {
                buf = MemHandleLock(bufH);
		if (export_type == CTIM_EXPORT_CSV)
		{
		  StrCat(buf, ",,");
		}
                StrCat(buf, lognote);
                MemHandleUnlock(bufH);
            }
        }
        else
        {
            // Event, not log
	    //
	    // Was there a previous contraction?
            if (tempprev == 0)
            {
	        // No previous; can't calc frequency
                err = MemHandleResize(
                        bufH, 
                        MemHandleSize(bufH) + StrLen(notime) + StrLen(separator));
                if (!err)
                {
                    buf = MemHandleLock(bufH);
                    StrCat(buf, notime);
                    StrCat(buf, separator);
                    MemHandleUnlock(bufH);
                }
            }
            else
            {
                // A frequency calculation is possible
                MemSet(num, sizeof(num), 0);
                SecsTo5Chars(tempstats.start_secs - tempprev, num);
                err = MemHandleResize(
                        bufH, 
                        MemHandleSize(bufH) + StrLen(num) + StrLen(separator));
                if (!err)
                {
                    buf = MemHandleLock(bufH);
                    StrCat(buf, num);
                    StrCat(buf, separator);
                    MemHandleUnlock(bufH);
                }
            }
        }

        // Add length/duration in mm:ss format
        if (tempstats.start_secs != tempstats.end_secs)
        {
            // Event, not log
            if (tempstats.end_secs != 0)
            {
                // This is an actually-ended contraction
                MemSet(num, sizeof(num), 0);
                SecsTo5Chars(tempstats.end_secs - tempstats.start_secs, num);
                err = MemHandleResize(
                        bufH, 
                        MemHandleSize(bufH) + StrLen(num) + StrLen(log_separator));
                if (!err)
                {
                    buf = MemHandleLock(bufH);
                    StrCat(buf, num);
                    StrCat(buf, log_separator);
                    MemHandleUnlock(bufH);
                }
            }
            else
            {
                // This is interrupted (or start button feedback)
                err = MemHandleResize(
                        bufH, 
                        MemHandleSize(bufH) + StrLen(notime) + StrLen(log_separator));
                if (!err)
                {
                    buf = MemHandleLock(bufH);
                    StrCat(buf, notime);
                    StrCat(buf, log_separator);
                    MemHandleUnlock(bufH);
                }
            }
        }
    
        // Add note (if any)
        if (tempstats.log_len)
        {
            MemSet(&note, sizeof(note), 0);
            LoadNote(rcdX, note);
            err = MemHandleResize(
                    bufH, 
                    MemHandleSize(bufH) + StrLen(note) + StrLen(end_separator));
            if (!err)
            {
                buf = MemHandleLock(bufH);
                StrCat(buf, note);
                StrCat(buf, end_separator);
                MemHandleUnlock(bufH);
            }
        }
        else
        {
            err = MemHandleResize(bufH, MemHandleSize(bufH) + 
	      StrLen(empty_end_separator));
            if (!err)
            {
                buf = MemHandleLock(bufH);
                StrCat(buf, empty_end_separator);
                MemHandleUnlock(bufH);
            }
        }

        // Check for buffer too big
        if (MemHandleSize(bufH) > maxsize)
        {
            // Truncate everything since last valid record
            MemHandleResize(bufH, prevsize);  // Shrinking always succeeds
            // Prepare to handle the previous record again
            rcdX--;
            // Last byte is no longer necessarily \0!
            buf = MemHandleLock(bufH);
            buf[prevsize - 1] = '\0';
            MemHandleUnlock(bufH);
            // save buf as a MemoPad record (frees handle)
            TextToMemo(dbMemo, bufH);
            // allocate a new buf
            fragment++;
            buf = InitMemo(dbMemo, &bufH, NO_NAME, fragment);
            if (!buf)
            {
                // Error creating additional memos
                err = 1;
            }
            else
            {
                //--JAM: change InitMemo so it's already unlocked...
                MemHandleUnlock(bufH);
            }
        }
        else  // Buffer was within MemoPad limits
        {
            // Set up for next record
            if (tempstats.start_secs != tempstats.end_secs)
            {
                // Count previous start only for actual events
                tempprev = tempstats.start_secs;
            }
        }

        /*
         * //--JAM: Should stop on memory error
         * if (err)
         * {
         *     // Break out of record loop
         *     rcdX = DmNumRecords(dbStats);
         * }
         */
    }

    // Try to save whatever we got (frees handle)
    TextToMemo(dbMemo, bufH);

    if (dbMemo)
    {
        DmCloseDatabase(dbMemo);
    }

    FrmCustomAlert(CTIM_RESULTS, "Data export complete.", " ", " ");
}

void *InitMemo(DmOpenRef inDb, VoidHand *bufH, char *mother_name, int part)
{
char *title = "Contraction Log ";
char *buf;
char *partstr = "part ";
char partbuf[30];  // Can't overflow with just an int
Err err;


    // New format shall be:
    // Mother's Name Contraction Log part <part>
    // Where Mother's Name is nothing in basic version

    // Silly checks
    if (part <= 0)
    {
        buf = NULL;
        return;
    }
    
    // Allocate some memory for the \0 at the end of the string
    *bufH = 0;
    *bufH = MemHandleNew(1);  
    if (*bufH)
    {
        buf = MemHandleLock(*bufH);
        buf[0] = '\0';  // Start with a null terminator
        MemHandleUnlock(*bufH);
    }
    else
    {
        buf = NULL;
        return buf;
    }

    // Copy on the Mother's Name
    if (StrLen(mother_name) > 0)
    {
        err = MemHandleResize(
                *bufH, 
                MemHandleSize(*bufH) + StrLen(mother_name) + StrLen(" "));
        if (!err)
        {
            buf = MemHandleLock(*bufH);
            StrCat(buf, mother_name);
            StrCat(buf, " ");
            MemHandleUnlock(*bufH);
        }
        else
        {
            buf = NULL;
            MemHandleFree(*bufH);
            return buf;
        }
    }

    // Add the Contraction Timer memo name
    err = MemHandleResize(*bufH, MemHandleSize(*bufH) + StrLen(title));
    if (!err)
    {
        buf = MemHandleLock(*bufH);
        StrCat(buf, title);
        MemHandleUnlock(*bufH);
    }
    else
    {
        MemHandleFree(*bufH);
        buf = NULL;
        return buf;
    }
    
    // Add on the part number
    StrIToA(partbuf, part);
    err = MemHandleResize(
            *bufH,
            MemHandleSize(*bufH) + StrLen(partstr) + StrLen(partbuf));
    if (!err)
    {
        buf = MemHandleLock(*bufH);
        StrCat(buf, partstr);
        StrCat(buf, partbuf);
        MemHandleUnlock(*bufH);
    }
    else
    {
        MemHandleFree(*bufH);
        buf = NULL;
        return buf;
    }

    // Advance to next field
    err = MemHandleResize(
              *bufH, 
              MemHandleSize(*bufH) + StrLen("\n\n"));
    if (!err)
    {
        buf = MemHandleLock(*bufH);
        StrCat(buf, "\n\n");
        MemHandleUnlock(*bufH);
    }
    else
    {
        MemHandleFree(*bufH);
        buf = NULL;
        return buf;
    }

    buf = MemHandleLock(*bufH);
    return buf;
}

// Handle must be unlocked before calling this function
void TextToMemo(DmOpenRef dbMemo, MemHandle bufH)
{
UInt16 at_end = dmMaxRecordIndex;
int rcdX;        
VoidHand rcdH;
void *rcdP;
char *buf;
Err err;

    // I tried a DmAttachRecord, but that's not possible unless the 
    // chunk is on the same card as the database.  While most Palms
    // only have one card, this is still not guaranteed.  Additionally,
    // the call to assure the memory was on the same card involved
    // the write-protected area of memory, requiring the use of
    // functions involving offsets (DmStrCopy, DmWrite).  I didn't
    // want to keep track of the offsets all the time, so I wrote an
    // algorythm that requires a bit more memory, but lets me stay
    // in dynamic memory until I'm ready to actually do the attaching.
    
    // Never hurts to check
    if (bufH)
    {
        buf = MemHandleLock(bufH);
        // Create a new MemoPad record
        rcdX = dmMaxRecordIndex;
        rcdH = DmNewRecord(dbMemo, (UInt *)&rcdX, MemHandleSize(bufH));
        if (rcdH)
        {
            rcdP = MemHandleLock(rcdH);
            // Save the \0 terminator
            DmWrite(rcdP, 0, buf, MemHandleSize(bufH));  
            MemHandleUnlock(rcdH);
            DmReleaseRecord(dbMemo, rcdX, true);
        }
        else
        {
            FrmCustomAlert(CTIM_RESULTS, "Couldn't save data.", " ", " ");
        }
        MemHandleUnlock(bufH);
        MemHandleFree(bufH);
    }
}

void UpdateCounter()
{
    ChangeLabel(CTIM_BTNELAPSED, " ");
    if ((stats.start_secs != 0) && (stats.end_secs == 0))
    {
        // A contraction is in progress
        MemSet(ElapsedText, sizeof(ElapsedText), 0);
        StrCat(ElapsedText, "Elapsed Time: ");
        SecsTo5Chars(TimGetSeconds() - stats.start_secs, ElapsedText);
        ChangeLabel(CTIM_BTNELAPSED, ElapsedText);
    }
}

// Frequency achieved notification
void Notify(void)
{
long curr_time;

    // Don't notify unless you mean it
    if (!notify)
    {
        return;
    }

    // Get the current time
    curr_time = TimGetSeconds();
    
    // If sound timeout achieved, play a sound
    if ((curr_time - last_sound_notify) >= NOTIFY_SOUND_TIMEOUT)
    {
        SndDoCmd(NULL, &note1, 0);
        SndDoCmd(NULL, &note2, 0);
        // Reset timeout
        last_sound_notify = curr_time;
    }

    // If flash timeout achieved, flash the indicator
    if ((curr_time - last_flash_notify) >= NOTIFY_FLASH_TIMEOUT)
    {
        // Flash the indicator (whether or not timeout achieved)
        if (notify_flash_step)
        {
            ChangeLabel(CTIM_BTNNOTIFY, "!");
        }
        else
        {
            ChangeLabel(CTIM_BTNNOTIFY, " ");
        }
        notify_flash_step = !notify_flash_step;
        last_flash_notify = curr_time;
    }
}

void UpdateNotificationIndicator(void)
{
    if (!notify)
    {
        // Indicator must be either waiting ellipsis or disabled X
        if (notify_freq == 0)
        {
            // Notification is disabled
            ChangeLabel(CTIM_BTNNOTIFY, "X");
        }
        else
        {
            // Notification is waiting
            ChangeLabel(CTIM_BTNNOTIFY, notify_waiting_label);
        }
    }
    else
    {
        // Update and increment the counter
        Notify();
    }
}

// Returns the secs of the previous non-log record in the dbStats.
// Returns 0 if no previous non-log record is found.
long PreviousStartSecs(int record)
{
long start;
Boolean found;
int rcdX;  // Won't work if this is a UInt!  Squashed v2.12.1.
contraction_stats tempstats;

    start = 0;
    found = false;
    for (rcdX = record - 1; ((rcdX >= 0) && !found); rcdX--)
    {
        LoadStat(rcdX, &tempstats);
        if (tempstats.start_secs != tempstats.end_secs)
        {
            // It's not a log
            start = tempstats.start_secs;
            found = true;
        }
    }
    return start;
    // Wasn't that beautiful structured programming?
}
