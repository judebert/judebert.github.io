<?php # $Id: comment.php 7 2005-04-16 06:39:31Z s_bergmann $
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity Developer Team)
# All rights reserved.  See LICENSE file for licensing details
# Serendipity is provided in managed mode here

require_once 's9y/comment.php';
/* vim: set sts=4 ts=4 expandtab : */
?>
