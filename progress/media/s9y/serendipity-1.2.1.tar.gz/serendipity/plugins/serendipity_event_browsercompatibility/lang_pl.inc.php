<?php # $Id: lang_pl.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'Kompatybilno�� z przegl�darkami');
@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', 'U�ywa r�nych metod CSS by wymusi� maksymaln� kompatybilno�� z r�nymi przegl�darkami. Uwaga: stwierdzono problemy u�ywania tej wtyczki przy korzystaniu z plik�w graficznych PNG. Wtyczka mo�e (ale nie musi) powodowa� przek�amania wy�wietlania plik�w graficznych PNG w przegl�darce Internet Explorer 6.x i ni�sze. Sprawd� wygl�d strony po w��czeniu tej wtyczki. Porada: wy��czenie wtyczki nie powoduje jakich� nieprzewidzianych efekt�w o ile u�ywa si� dobrze zaprojektowanego stylu.');

?>
