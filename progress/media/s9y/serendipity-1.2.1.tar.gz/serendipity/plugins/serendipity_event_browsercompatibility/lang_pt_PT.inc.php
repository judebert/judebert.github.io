<?php # $Id:$

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Jo�o P Matos <jmatos@math.ist.utl.pt>                                  #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'Compatibilidade de navegadores');
@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', 'Utiliza diferentes m�todos de CSS para assegurar compatibilidade com o maior n�mero de navegadores poss�vel.');

/* vim: set sts=4 ts=4 expandtab : */
?>
