<?php # $id: $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								                                 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', '瀏覽器相容性');
        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', '使用各種 CSS 樣式的方法來確定每個瀏覽器都能相容');
?>