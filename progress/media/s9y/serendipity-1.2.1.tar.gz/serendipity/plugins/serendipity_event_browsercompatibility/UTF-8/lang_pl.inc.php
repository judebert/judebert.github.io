<?php # $Id: lang_pl.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'Kompatybilność z przeglądarkami');
@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', 'Używa różnych metod CSS by wymusić maksymalną kompatybilność z różnymi przeglądarkami. Uwaga: stwierdzono problemy używania tej wtyczki przy korzystaniu z plików graficznych PNG. Wtyczka może (ale nie musi) powodować przekłamania wyświetlania plików graficznych PNG w przeglądarce Internet Explorer 6.x i niższe. Sprawdź wygląd strony po włączeniu tej wtyczki. Porada: wyłączenie wtyczki nie powoduje jakichś nieprzewidzianych efektów o ile używa się dobrze zaprojektowanego stylu.');

?>
