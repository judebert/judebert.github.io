<?php # $Id: lang_ko.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', '브라우저 호환성');
        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', '브라우저 호환성을 최대화하기 위해 다른 종류의 (CSS) 방식을 사용함');

?>
