<?php # $Id: lang_es.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
/**
 *  @version $Revision: 1381 $
 *  @author Rodrigo Lazo Paz <rlazo.paz@gmail.com>
 *  EN-Revision: 690
 */

@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'Compatibilidad con el navegador');
@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', 'Utiliza distintos métodos (CSS) para asegurar máxima compatibilidad con el navegador.');

?>