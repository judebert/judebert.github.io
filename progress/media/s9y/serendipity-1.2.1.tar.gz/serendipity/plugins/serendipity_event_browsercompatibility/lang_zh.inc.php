<?php

@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', '浏览器兼容');
@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', '使用不同的CSS样式表述方法以最大限度地兼容各种浏览器');
