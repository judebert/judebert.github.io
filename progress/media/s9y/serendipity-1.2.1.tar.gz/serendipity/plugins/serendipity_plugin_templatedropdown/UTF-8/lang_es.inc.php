<?php # $Id: lang_es.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Rodrigo Lazo Paz <rlazo.paz@gmail.com>
 *  EN-Revision: 690
 */

@define('PLUGIN_TEMPLATEDROPDOWN_NAME',     'Caja desplegable de plantillas');
@define('PLUGIN_TEMPLATEDROPDOWN_DESC',     'Muestra una caja desplegable para cambiar las plantillas');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',   '¿Botón de enviar?');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',   '¿Mostrar un botón de envío?');

?>
