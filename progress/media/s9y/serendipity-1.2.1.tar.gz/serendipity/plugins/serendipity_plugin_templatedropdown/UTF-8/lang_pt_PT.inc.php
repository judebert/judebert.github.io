<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# João P Matos <jmatos@math.ist.utl.pt>                                  #
#                                                                        #
##########################################################################

@define('PLUGIN_TEMPLATEDROPDOWN_NAME',     'Selector de temas');
@define('PLUGIN_TEMPLATEDROPDOWN_DESC',     'Mostra um menu para mudar o tema visual');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',   'Incluir o botão?');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',   'Mostrar um botão de submissão?');

/* vim: set sts=4 ts=4 expandtab : */
?>