<?php # $Id: lang_ko.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_TEMPLATEDROPDOWN_NAME',     '템플릿 선택');
        @define('PLUGIN_TEMPLATEDROPDOWN_DESC',     '템플릿을 바꿀 수 있는 목록 상자를 보여줌');
        @define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',   'Submit 버튼');
        @define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',   'Submit 버튼을 표시합니까?');

?>
