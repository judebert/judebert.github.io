<?php # $Id: lang_pl.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_TEMPLATEDROPDOWN_NAME', 'Wybór stylu');
@define('PLUGIN_TEMPLATEDROPDOWN_DESC', 'Pokazuje pole wyboru, które umożliwia użytkownikowi samodzielny wybór stylu, jakim ma być wyświetlany blog');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT', 'Przycisk potwierdzenia (submit)?');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC', 'Czy przycisk potwoerdzenia ma być pokazywany?');

?>
