<?php # $Id: lang_bg.inc.php 1419 2006-08-29 10:25:22Z jwalker $

/**
 *  @version $Revision: 1419 $
 *  @author Ivan Cenov jwalker@hotmail.bg
 */

@define('PLUGIN_TEMPLATEDROPDOWN_NAME',     'Избор на теми');
@define('PLUGIN_TEMPLATEDROPDOWN_DESC',     'Показва падащ списък за избор на тема');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',   'Бутон \'Изпращане\'?');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',   'При избор \'Да\' смяната на темата ще се осъществява след натискане на бутон \'Продължаване\'.');
