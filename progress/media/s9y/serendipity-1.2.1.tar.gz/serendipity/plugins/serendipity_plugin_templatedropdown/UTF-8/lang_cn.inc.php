<?php

@define('PLUGIN_TEMPLATEDROPDOWN_NAME', '主题选择');
@define('PLUGIN_TEMPLATEDROPDOWN_DESC', '显示一个选择主题的下拉框');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT', '提交按钮');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC', '是否显示一个提交按钮（用于切换所选择的主题）？');
