<?php # $Id: lang_pl.inc.php 1609 2007-02-06 08:35:09Z garvinhicking $

/**
 *  @version $Revision: 1609 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_BBCODE_NAME',     'Znacznik: BBCode');
@define('PLUGIN_EVENT_BBCODE_DESC',     'Przekształcaj tekst stosując tagi BBCode');
@define('PLUGIN_EVENT_BBCODE_TRANSFORM', '<a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a> format dozwolony');
@define('PLUGIN_EVENT_BBCODE_TARGET',   'Używać target="blank" dla linków?');
