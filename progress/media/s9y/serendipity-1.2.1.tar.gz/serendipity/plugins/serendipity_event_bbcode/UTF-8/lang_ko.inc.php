<?php # $Id: lang_ko.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_BBCODE_NAME',     '마크업: BB코드');
        @define('PLUGIN_EVENT_BBCODE_DESC',     'BB코드 마크업을 글에 적용함');
        @define('PLUGIN_EVENT_BBCODE_TRANSFORM', '<a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BB코드</a>를 글에 쓸 수 있습니다.');

?>
