<?php

@define('PLUGIN_EVENT_BBCODE_NAME', '标记语言: BBCode');
@define('PLUGIN_EVENT_BBCODE_DESC', '使用BBCode标记语言');
@define('PLUGIN_EVENT_BBCODE_TRANSFORM', '允许使用<a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a>格式代码');
@define('PLUGIN_EVENT_BBCODE_TARGET',   '处理链接时使用 target="blank"？(点击链接后在新窗口显示网页内容)');
