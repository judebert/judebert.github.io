<?php # $Id: lang_bg.inc.php 1419 2006-08-29 10:25:22Z jwalker $

/**
 *  @version $Revision: 1419 $
 *  @author Ivan Cenov jwalker@hotmail.bg
 */
 
        @define('PLUGIN_EVENT_BBCODE_NAME',     'Текстово форматиране: BBCode');
        @define('PLUGIN_EVENT_BBCODE_DESC',     'Форматиране на текст (постинг, коментар, HTML поле) с BBcode');
        @define('PLUGIN_EVENT_BBCODE_TRANSFORM', 'Форматирането с <a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a> е разрешено');
        @define('PLUGIN_EVENT_BBCODE_TARGET',   'Използване на target="blank" за връзките ?');
