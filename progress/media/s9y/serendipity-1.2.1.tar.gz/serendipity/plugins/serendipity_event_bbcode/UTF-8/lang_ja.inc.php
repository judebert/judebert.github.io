<?php # $Id: lang_ja.inc.php 1712 2007-06-06 04:23:06Z elf2000 $

/**
 *  @version $Revision: 1712 $
 *  @author Tadashi Jokagi <elf2000@users.sourceforge.net>
 *  EN-Revision: 1410
 */

@define('PLUGIN_EVENT_BBCODE_NAME',     'マークアップ: BB コード');
@define('PLUGIN_EVENT_BBCODE_DESC',     'BB コードを使用したテキストマークアップです。');
@define('PLUGIN_EVENT_BBCODE_TRANSFORM', '<a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BB コード</a> 書式を許可します。');
@define('PLUGIN_EVENT_BBCODE_TARGET',   'リンクに「target="blank"」を使いますか?');

?>
