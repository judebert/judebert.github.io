<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_BBCODE_NAME',     'Textformatierung: BBCode');
        @define('PLUGIN_EVENT_BBCODE_DESC',     'BBCode-Formatierung durchführen');
        @define('PLUGIN_EVENT_BBCODE_TRANSFORM', '<a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a>-Formatierung erlaubt');
