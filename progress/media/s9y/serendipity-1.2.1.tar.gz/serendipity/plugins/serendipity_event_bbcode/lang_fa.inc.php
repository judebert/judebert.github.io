<?php # $Id: lang_fa.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Omid Mottaghi <webmaster@oxygenws.com>
 *  EN-Revision: Revision of lang_fa.inc.php
 */

@define('PLUGIN_EVENT_BBCODE_NAME',     'برچسب: BBCode');
@define('PLUGIN_EVENT_BBCODE_DESC',     'برچسب زدن به نوشته ها توسط BBCode');
@define('PLUGIN_EVENT_BBCODE_TRANSFORM', 'روش های <a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BB Code</a> مجاز می باشند');

?>
