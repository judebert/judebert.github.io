<?php # $Id: lang_pl.inc.php 1548 2006-12-20 18:26:17Z garvinhicking $

/**
 *  @version $Revision: 1548 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_BBCODE_NAME',     'Znacznik: BBCode');
@define('PLUGIN_EVENT_BBCODE_DESC',     'Przekszta�caj tekst stosuj�c tagi BBCode');
@define('PLUGIN_EVENT_BBCODE_TRANSFORM', '<a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a> format dozwolony');
@define('PLUGIN_EVENT_BBCODE_TARGET',   'U�ywa� target="blank" dla link�w?');
