<?

@define('PLUGIN_ENTRYLINKS_NAME', '文章链接');
@define('PLUGIN_ENTRYLINKS_BLAHBLAH', '显示涉及该文章的所有链接');
@define('PLUGIN_ENTRYLINKS_NEWWIN', '在新窗口中打开链接');
@define('PLUGIN_ENTRYLINKS_NEWWIN_BLAHBLAH', '是否在新窗口中打开链接？(默认：在当前窗口打开)');
@define('PLUGIN_ENTRYLINKS_REFERERS', '来源链接');
@define('PLUGIN_ENTRYLINKS_WORDWRAP', '自动换行');
@define('PLUGIN_ENTRYLINKS_WORDWRAP_BLAHBLAH', '在多少个字符之后自动换行(默认：30)');
@define('PLUGIN_ENTRYLINKS_MAXREF', '来源链接数量');
@define('PLUGIN_ENTRYLINKS_MAXREF_BLAHBLAH', '显示多少个来源链接(默认：15)');
@define('PLUGIN_ENTRYLINKS_ORDERBY', '排列来源链接');
@define('PLUGIN_ENTRYLINKS_ORDERBY_BLAHBLAH', '以何种顺序排列来源链接(默认：链入次数)');
@define('PLUGIN_ENTRYLINKS_ORDERBY_DAY', '日期');
@define('PLUGIN_ENTRYLINKS_ORDERBY_FULLCOUNT', '链入次数');
