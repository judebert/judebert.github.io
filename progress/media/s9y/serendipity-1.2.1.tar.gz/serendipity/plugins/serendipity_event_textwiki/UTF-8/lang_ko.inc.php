<?php # $Id: lang_ko.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_TEXTWIKI_NAME',     '마크업: 위키');
        @define('PLUGIN_EVENT_TEXTWIKI_DESC',     '텍스트_위키 마크업을 글에 사용함 Markup text using Text_Wiki');
        @define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM', '<a href="http://c2.com/cgi/wiki">위키</a> 포맷을 글에 쓸 수 있습니다.');

?>
