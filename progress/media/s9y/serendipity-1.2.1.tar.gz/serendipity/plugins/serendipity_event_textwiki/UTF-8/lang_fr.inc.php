<?php # $Id: lang_fr.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_TEXTWIKI_NAME',     'Balises: Wiki');
@define('PLUGIN_EVENT_TEXTWIKI_DESC',     'Permet l\'utilisation de la Syntaxe Wiki dans le texte de vos billets');
@define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM', 'Syntaxe <a href="http://c2.com/cgi/wiki">Wiki</a> autorisée');

/* vim: set sts=4 ts=4 expandtab : */
?>