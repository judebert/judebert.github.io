<?php # $Id: lang_en.inc.php 690 2005-11-13 04:49:04Z elf2000 $

/**
 *  @version $Revision: 690 $
 *  @author Henrik Schack <henrik@schack.dk>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Formatering: Serendipity');
@define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Anvend grundl�ggende serendipity formatering p� indtastet tekst');
@define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Omsluttende stjerner markerer tekst som fed (*ord*), understregning laves med _ord_.');

?>
