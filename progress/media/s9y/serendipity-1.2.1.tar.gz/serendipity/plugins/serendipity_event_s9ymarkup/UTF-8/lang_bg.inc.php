<?php # $Id: lang_bg.inc.php 1419 2006-08-29 10:25:22Z jwalker $

/**
 *  @version $Revision: 1419 $
 *  @author Ivan Cenov jwalker@hotmail.bg
 */

    @define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Текстово форматиране: Serendipity');
    @define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Прилага базово форматиране на текст');
    @define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Звездички означават bold (*текст*), подчертаване се прави с "_" (_текст_)');
