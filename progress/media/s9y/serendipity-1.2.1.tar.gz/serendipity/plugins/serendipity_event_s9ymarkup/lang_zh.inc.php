<?php

@define('PLUGIN_EVENT_S9YMARKUP_NAME', '标记语言：Serendipity');
@define('PLUGIN_EVENT_S9YMARKUP_DESC', '对文章使用基本的 Serendipity标记语言进行处理');
@define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', '用星号围住文章(例如 *word*)会以粗体样式显示，而用下划线围住文章(例如 _word_)会以带下划线的方式显示');

@define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Enclosing asterisks marks text as bold (*word*), underscore are made via _word_.');
