<?php # $Id: lang_cs.inc.php 1381 2007-11-20 00:00:00Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Vladimir Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Markup: Serendipity');
@define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Prov�d� z�kladn� zna�kov�n� textu.');
@define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Slova mezi hv�zdi�kami budou tu�n� (*tu�n�*), podtr�en� podobn� pomoc� podtr��tek _podtr�en�_.');
