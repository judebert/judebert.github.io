<?php # $Id: lang_is.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Textabreyting: Serendipity');
        @define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Virkja grunntextabreytingar � texta � f�rslum');
        @define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'A� setja texta innan stjarna gerir hann feitletra�an (*or�*), og til a� undirstrika setur ma�ur strik ni�ri � undan og eftir or�i (_or�_).');

/* vim: set sts=4 ts=4 expandtab : */
?>