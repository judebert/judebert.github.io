<?php # $Id: lang_ja.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Tadashi Jokagi <elf2000@users.sourceforge.net>
 *  EN-Revision: 690
 */

@define('PLUGIN_EVENT_TEXTILE_NAME', 'マークアップ: テクスタイル');
@define('PLUGIN_EVENT_TEXTILE_DESC', 'テクスタールコンバーターを通して出力をすべて解析します。');
@define('PLUGIN_EVENT_TEXTILE_TRANSFORM', '<a href="http://www.textism.com/tools/textile/">テクスタイル</a> 書式を許可します。');

?>
