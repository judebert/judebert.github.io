<?php # $Id: lang_ko.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_TEXTILE_NAME', '마크업: 텍스타일');
        @define('PLUGIN_EVENT_TEXTILE_DESC', '텍스타일 변환기를 통해 모든 출력을 변환시킴');
        @define('PLUGIN_EVENT_TEXTILE_TRANSFORM', '<a href="http://www.textism.com/tools/textile/">텍스타일</a> 포맷을 글에 쓸 수 있습니다.');

?>
