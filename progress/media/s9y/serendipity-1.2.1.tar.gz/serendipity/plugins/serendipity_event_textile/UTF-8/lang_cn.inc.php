<?php

@define('PLUGIN_EVENT_TEXTILE_NAME', '标记语言：Textile');
@define('PLUGIN_EVENT_TEXTILE_DESC', '将所有页面输出通过Textile转换处理');
@define('PLUGIN_EVENT_TEXTILE_TRANSFORM', '允许使用<a href="http://www.textism.com/tools/textile/">Textile</a>格式。');
