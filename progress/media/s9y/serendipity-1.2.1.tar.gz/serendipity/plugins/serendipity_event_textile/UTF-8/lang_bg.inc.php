<?php # $Id: lang_bg.inc.php 2061 2007-12-06 11:12:30Z garvinhicking $

/**
 *  @version $Revision: 2061 $
 *  @author Ivan Cenov jwalker@hotmail.bg
  *  EN-Revision: 2034
*/

    @define('PLUGIN_EVENT_TEXTILE_NAME', 'Форматиране на текст: Textile');
    @define('PLUGIN_EVENT_TEXTILE_DESC', 'Форматиране на текст чрез Textile конвертор.');
    @define('PLUGIN_EVENT_TEXTILE_TRANSFORM', 'Форматиране <a href="http://www.textism.com/tools/textile/">Textile</a> е разрешено');
    @define('PLUGIN_EVENT_TEXTILE_VERSION', 'Версия на Textile');
    @define('PLUGIN_EVENT_TEXTILE_VERSION_DESCRIPTION', 'Коя версия на Textile искате да използвате?');
