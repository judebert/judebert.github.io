<?php # $Id: lang_fr.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_TEXTILE_NAME', 'Balises: Textile');
@define('PLUGIN_EVENT_TEXTILE_DESC', 'Permet l\'utilisation de balises Textile dans le texte des billets');
@define('PLUGIN_EVENT_TEXTILE_TRANSFORM', 'Syntaxe <a href="http://www.textism.com/tools/textile/">Textile</a> autorisée');

/* vim: set sts=4 ts=4 expandtab : */
?>