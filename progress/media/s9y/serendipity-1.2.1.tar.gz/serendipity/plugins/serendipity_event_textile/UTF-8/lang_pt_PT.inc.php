<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# João P Matos <argh@php-tools.net>                                #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_TEXTILE_NAME', 'Código: Textile');
@define('PLUGIN_EVENT_TEXTILE_DESC', 'Filtra o texto das entradas através do conversor Textile');
@define('PLUGIN_EVENT_TEXTILE_TRANSFORM', 'Síntaxe <a href="http://www.textism.com/tools/textile/">Textile</a> autorizada');

/* vim: set sts=4 ts=4 expandtab : */
?>