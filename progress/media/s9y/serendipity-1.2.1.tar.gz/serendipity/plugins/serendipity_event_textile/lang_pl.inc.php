<?php # $Id: lang_pl.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_TEXTILE_NAME', 'Znacznik: Textile');
@define('PLUGIN_EVENT_TEXTILE_DESC', 'Parsuj ca�� tre�� przez modu� konwertera Textile');
@define('PLUGIN_EVENT_TEXTILE_TRANSFORM', '<a href="http://www.textism.com/tools/textile/">Textile</a>-format dozwolony');

?>
