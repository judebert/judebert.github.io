<?php # $Id: lang_en.inc.php 2054 2007-12-06 09:26:35Z garvinhicking $

/**
 *  @version $Revision: 2054 $
 *  @author Translator Name <yourmail@example.com>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_TEXTILE_NAME', 'Markup: Textile');
@define('PLUGIN_EVENT_TEXTILE_DESC', 'Parse all output through the Textile converter');
@define('PLUGIN_EVENT_TEXTILE_TRANSFORM', '<a href="http://www.textism.com/tools/textile/">Textile</a>-formatting allowed');
@define('PLUGIN_EVENT_TEXTILE_VERSION', 'Textile version');
@define('PLUGIN_EVENT_TEXTILE_VERSION_DESCRIPTION', 'Which version of Textile do you want to use?');
?>
