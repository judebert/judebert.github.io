<?php # $Id: lang_de.inc.php 2054 2007-12-06 09:26:35Z garvinhicking $

@define('PLUGIN_EVENT_TEXTILE_NAME',     'Textformatierung: Textile');
@define('PLUGIN_EVENT_TEXTILE_DESC',     'Textile-Formatierung durchf�hren');
@define('PLUGIN_EVENT_TEXTILE_TRANSFORM', '<a href="http://www.textism.com/tools/textile/">Textile</a>-Formatierung erlaubt');
@define('PLUGIN_EVENT_TEXTILE_VERSION', 'Textile-Version');
@define('PLUGIN_EVENT_TEXTILE_VERSION_DESCRIPTION', 'Welche Version von Textile soll verwendet werden?');

