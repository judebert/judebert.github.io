<?php # $Id: lang_en.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Translator Name <yourmail@example.com>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_NAME', 'Creative Commons');
@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_DESC', 'Display a creative commons notification in the sidebar.');

?>
