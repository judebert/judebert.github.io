<?php # $Id: lang_ko.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_SIDEBAR_CREATIVECOMMONS_NAME', '크리에이티브 커먼스');
        @define('PLUGIN_SIDEBAR_CREATIVECOMMONS_DESC', '옆줄에 크리에이티브 커먼스 안내 표시를 함');

?>
