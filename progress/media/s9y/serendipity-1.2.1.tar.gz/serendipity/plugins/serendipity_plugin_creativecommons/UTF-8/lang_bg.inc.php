<?php # $Id: lang_bg.inc.php 1419 2006-08-29 10:25:22Z jwalker $

/**
 *  @version $Revision: 1419 $
 *  @author Ivan Cenov jwalker@hotmail.bg
 */

@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_NAME', 'Creative Commons');
@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_DESC', 'Показва известяване от creative commons в страничния панел.');
