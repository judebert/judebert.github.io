<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_XHTMLCLEANUP_NAME', '�bliche XHTML-Fehler beseitigen');
        @define('PLUGIN_EVENT_XHTMLCLEANUP_DESC', 'Korrigiert �bliche Fehler, die beim XHTML-Markup der Eintr�ge gemacht werden k�nnen');
