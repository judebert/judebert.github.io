<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_XHTMLCLEANUP_NAME', 'Übliche XHTML-Fehler beseitigen');
        @define('PLUGIN_EVENT_XHTMLCLEANUP_DESC', 'Korrigiert übliche Fehler, die beim XHTML-Markup der Einträge gemacht werden können');
