<?php # $Id: lang_pl.inc.php 1548 2006-12-20 18:26:17Z garvinhicking $

/**
 *  @version $Revision: 1548 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_NL2BR_NAME', 'Znacznik: NL2BR');
@define('PLUGIN_EVENT_NL2BR_DESC', 'Zmieniaj znaki nowych linii na tagi BR');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS', 'Lista tag�w HTML, w kt�rych znacznik nie powinien by� stosowany');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS_DESC', 'Sugestia: "code,pre,geshi,textarea". Rozdzielaj tagi przecinkiem. Podpowied�: wpisane tagi s� traktowane jako zwyk�e wyra�enia.');
?>
