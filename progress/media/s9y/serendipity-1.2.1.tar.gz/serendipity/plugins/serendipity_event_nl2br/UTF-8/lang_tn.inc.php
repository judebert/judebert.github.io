<?php # $Id: lang_tn.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								                                 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_EVENT_NL2BR_NAME',     '標記語言: NL2BR');
        @define('PLUGIN_EVENT_NL2BR_DESC',     '轉換新行成 BR 標籤');
?>