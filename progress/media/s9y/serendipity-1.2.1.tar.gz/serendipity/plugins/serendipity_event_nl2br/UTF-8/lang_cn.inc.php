<?php

@define('PLUGIN_EVENT_NL2BR_NAME', '标记语言: NL2BR');
@define('PLUGIN_EVENT_NL2BR_DESC', '将换行转换成HTML的BR标签');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS', '在下列HTML标签所含内容中，不转换换行');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS_DESC', '推荐的HTML标签: "code,pre,geshi,textarea". 不同HTML标签使用逗号分割。小提示：Serendipity使用正则表达式(regular expressions)来处理、分析这里输入的标签。');
