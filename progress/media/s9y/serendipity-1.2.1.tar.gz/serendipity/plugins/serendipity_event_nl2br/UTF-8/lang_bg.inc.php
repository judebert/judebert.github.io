<?php # $Id: lang_bg.inc.php 1511 2006-11-16 17:39:33Z jwalker $

/**
 *  @version $Revision: 1511 $
 *  @author Ivan Cenov jwalker@hotmail.bg
 */

@define('PLUGIN_EVENT_NL2BR_NAME',     'Форматиране на текст: NL2BR');
@define('PLUGIN_EVENT_NL2BR_DESC',     'Заменя новите редове в текста с HTML BR тагове');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS', 'Списък на HTML-тагове, в които няма да се използва това форматиране');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS_DESC', 'Препоръка: "code,pre,geshi,textarea". Използвайте "," за да укажете повече от един таг. Забележка: Въведените тагове се изчисляват като регулярни изрази.');
