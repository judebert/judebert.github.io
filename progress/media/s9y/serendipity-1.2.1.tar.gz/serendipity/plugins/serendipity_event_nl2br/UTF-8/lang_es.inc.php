<?php # $Id: lang_es.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
/**
 *  @version $Revision: 1381 $
 *  @author Rodrigo Lazo Paz <rlazo.paz@gmail.com>
 *  EN-Revision: 690
 */

@define('PLUGIN_EVENT_NL2BR_NAME',     'Formato: NL2BR');
@define('PLUGIN_EVENT_NL2BR_DESC',     'Convierte los saltos de linea en etiquetas BR');

?>
