<?php # $Id: lang_pl.inc.php 1609 2007-02-06 08:35:09Z garvinhicking $

/**
 *  @version $Revision: 1609 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_NL2BR_NAME', 'Znacznik: NL2BR');
@define('PLUGIN_EVENT_NL2BR_DESC', 'Zmieniaj znaki nowych linii na tagi BR');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS', 'Lista tagów HTML, w których znacznik nie powinien być stosowany');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS_DESC', 'Sugestia: "code,pre,geshi,textarea". Rozdzielaj tagi przecinkiem. Podpowiedź: wpisane tagi są traktowane jako zwykłe wyrażenia.');
?>