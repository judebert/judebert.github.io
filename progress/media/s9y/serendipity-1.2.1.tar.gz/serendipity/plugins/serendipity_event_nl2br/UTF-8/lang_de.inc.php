<?php # $Id: lang_de.inc.php 1501 2006-11-14 09:23:16Z garvinhicking $

@define('PLUGIN_EVENT_NL2BR_NAME',     'Textformatierung: NL2BR');
@define('PLUGIN_EVENT_NL2BR_DESC',     'Konvertiert Zeilenumbrüche zu HTML');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS', 'Eine Liste von HTML-Tags, innerhalb derer keine Umbrüche konvertiert werden');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS_DESC', 'Konfigurationsvorschlag: "code,pre,geshi,textarea". Trennen Sie mehrere HTML-Tags mit Komma. Hinweis: Die eingegebenen Tags sind reguläre Ausdrücke!');