<?php # $Id: lang_cz.inc.php 1501 2007-11-30 09:20:00 VladaAjgl $

/**
 *  @version $Revision: 1501 $
 *  @author Vladim�r Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 *  Translated on 2007/11/30
 */

@define('PLUGIN_EVENT_NL2BR_NAME',              'Markup: NL2BR');
@define('PLUGIN_EVENT_NL2BR_DESC',              'M�n� znaky konce ��dku na tagy <br />');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS',      'Seznam html tag�, uvnit� kter�ch nemaj� b�t konce ��dk� nahrazov�ny.');
@define('PLUGIN_EVENT_NL2BR_ISOLATE_TAGS_DESC', 'N�vrhy: "code,pre,geshi,textarea". N�zvy tag� odd�lujte ��rkou. Tip: Zad�van� tagy jsou vyhodnocov�ny jako regul�rn� v�raz.');
?>
