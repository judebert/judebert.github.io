<?php # $Id: lang_es.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Rodrigo Lazo Paz <rlazo.paz@gmail.com>
 *  EN-Revision: 690
 */

@define('PLUGIN_EVENT_WRAPPER_NAME', 'Encapsulador de la salida de eventos');
@define('PLUGIN_EVENT_WRAPPER_DESC', 'Muestra informaci�n obtenida a trav�s de cierta extensi�n de evento');
@define('PLUGIN_EVENT_WRAPPER_PLUGIN', 'Extensi�n de evento fuente');
@define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', 'Selecciona la extensi�n de evento cuya salida debe ser mostrada');
@define('PLUGIN_EVENT_WRAPPER_TITLEDESC', 'Ingresa el t�tulo para este elemento de la barra lateral (d�jalo vac�o para heredarlo de la extensi�n)');

?>
