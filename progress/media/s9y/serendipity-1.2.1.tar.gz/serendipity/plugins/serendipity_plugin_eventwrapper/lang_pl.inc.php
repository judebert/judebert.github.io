<?php # $Id: lang_pl.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_WRAPPER_NAME', 'Eksporter danych Wtyczek Zdarze�');
@define('PLUGIN_EVENT_WRAPPER_DESC', 'Pokazuje dane zebrane z kilku Wtyczek Zdarze�');
@define('PLUGIN_EVENT_WRAPPER_PLUGIN', '�r�d�owa Wtyczka Zdarzenia');
@define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', 'Wybierz wtyczk�, kt�rej dane maj� by� pokazane');
@define('PLUGIN_EVENT_WRAPPER_TITLEDESC', 'Wprowad� tytu� pozycji wy�wietlonej w Panelu Bocznym	Enter (zostaw puste by pozostawi� nazw� wtyczki, z kt�rej dane b�d� pobierane)');

?>
