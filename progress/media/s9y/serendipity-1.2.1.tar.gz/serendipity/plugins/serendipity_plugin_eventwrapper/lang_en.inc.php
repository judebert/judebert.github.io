<?php # $Id: lang_en.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Translator Name <yourmail@example.com>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_WRAPPER_NAME', 'Event-Output wrapper');
@define('PLUGIN_EVENT_WRAPPER_DESC', 'Displays gathered data by a certain event plugin');
@define('PLUGIN_EVENT_WRAPPER_PLUGIN', 'Source event plugin');
@define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', 'Select the event plugin for which the output should be displayed');
@define('PLUGIN_EVENT_WRAPPER_TITLEDESC', 'Enter the title for this sidebar item (leave empty for inheritance by event plugin)');

?>
