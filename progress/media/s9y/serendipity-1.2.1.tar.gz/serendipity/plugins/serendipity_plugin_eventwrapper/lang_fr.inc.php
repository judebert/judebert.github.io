<?php # $Id: lang_fr.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_WRAPPER_NAME', 'Collecteur de donn�es de plugins');
@define('PLUGIN_EVENT_WRAPPER_DESC', 'Affiche les donn�es g�n�r�es par un plugin d\'�v�nement donn�.');
@define('PLUGIN_EVENT_WRAPPER_PLUGIN', 'Plugin d\'�v�nement source');
@define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', 'S�lectionnez le plugin dont les donn�es doivent �tre affich�s');
@define('PLUGIN_EVENT_WRAPPER_TITLEDESC', 'Entrez le titre de cet �l�ment de barre lat�rale (laisser vide pour h�riter le titre du plugin d\'�v�nement)');

/* vim: set sts=4 ts=4 expandtab : */
?>