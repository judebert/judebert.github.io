<?php

@define('PLUGIN_EVENT_WRAPPER_NAME', '事件输出');
@define('PLUGIN_EVENT_WRAPPER_DESC', '通过特定事件插件输出相关内容');
@define('PLUGIN_EVENT_WRAPPER_PLUGIN', '事件插件');
@define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', '选择使用哪个事件插件来处理相关的输出内容');
@define('PLUGIN_EVENT_WRAPPER_TITLEDESC', '在此输入该侧栏栏目的标题 (如果此处留空的话，则将使用事件插件所生成的标题)');
