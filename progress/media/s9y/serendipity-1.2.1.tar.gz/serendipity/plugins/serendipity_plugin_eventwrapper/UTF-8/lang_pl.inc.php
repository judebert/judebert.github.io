<?php # $Id: lang_pl.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_WRAPPER_NAME', 'Eksporter danych Wtyczek Zdarzeń');
@define('PLUGIN_EVENT_WRAPPER_DESC', 'Pokazuje dane zebrane z kilku Wtyczek Zdarzeń');
@define('PLUGIN_EVENT_WRAPPER_PLUGIN', 'Źródłowa Wtyczka Zdarzenia');
@define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', 'Wybierz wtyczkę, której dane mają być pokazane');
@define('PLUGIN_EVENT_WRAPPER_TITLEDESC', 'Wprowadź tytuł pozycji wyświetlonej w Panelu Bocznym	Enter (zostaw puste by pozostawić nazwę wtyczki, z której dane będą pobierane)');

?>
