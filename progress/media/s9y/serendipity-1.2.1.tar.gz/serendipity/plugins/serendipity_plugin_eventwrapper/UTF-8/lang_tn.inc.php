<?php # $Id: lang_tn.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								                                 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_EVENT_WRAPPER_NAME', '事件輸出');
        @define('PLUGIN_EVENT_WRAPPER_DESC', '顯示某個事件外掛的輸出資料');
        @define('PLUGIN_EVENT_WRAPPER_PLUGIN', '來源外掛');
        @define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', '選擇要顯示輸出資料的事件外掛');
        @define('PLUGIN_EVENT_WRAPPER_TITLEDESC', '在側列顯示的標題 (輸入空白如果要用來源外掛的名稱)');
?>