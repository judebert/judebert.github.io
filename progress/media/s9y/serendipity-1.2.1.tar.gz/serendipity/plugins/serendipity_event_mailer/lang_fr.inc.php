<?php # $Id: lang_fr.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_MAILER_NAME', 'Envoyer les billets par E-Mail');
@define('PLUGIN_EVENT_MAILER_DESC', 'Envoie un billet par Email � un destinataire de votre choix lorsqu\'il est publi�');
@define('PLUGIN_EVENT_MAILER_RECIPIENT', 'Destinataire');
@define('PLUGIN_EVENT_MAILER_RECIPIENTDESC', 'L\'adresse Email � laquelle le billet dot �tre envoy� (suggestion: une mailing list)');
@define('PLUGIN_EVENT_MAILER_LINK', 'Envoyer un lien au billet?');
@define('PLUGIN_EVENT_MAILER_LINKDESC', 'Inclut un lien au billet original dans l\'email.');
@define('PLUGIN_EVENT_MAILER_STRIPTAGS', 'Enlever le HTML?');
@define('PLUGIN_EVENT_MAILER_STRIPTAGSDESC', 'Enl�ve toutes les balises HTML contenues dans le billet.');
@define('PLUGIN_EVENT_MAILER_CONVERTP', 'Convertir les paragraphes HTML en retours � la ligne?');
@define('PLUGIN_EVENT_MAILER_CONVERTPDESC', 'Ajoute un retour � la ligne apr�s chaque paragraphe HTML. Cette option est tr�s utile pour pr�verver les paragraphes dans le texte si vous avez activ� l\'option d\'enlever les balises HTML.');
@define('PLUGIN_EVENT_MAILER_RECIPIENTS', 'Destinataire(s) email (s�parez plusieurs destinataires avec des espaces)');
@define('PLUGIN_EVENT_MAILER_NOTSENDDECISION', 'Ce billet n\'a pas �t� envoy� par email parce-que vous avec d�cid� de ne pas l\'envoyer.');
@define('PLUGIN_EVENT_MAILER_SENDING', 'Envoi...');
@define('PLUGIN_EVENT_MAILER_ISTOSENDIT', 'Envoyer ce billet par email');

/* vim: set sts=4 ts=4 expandtab : */
?>