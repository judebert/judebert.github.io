<?php # $Id: lang_fr.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_COMMENTS_BLAHBLAH', 'Affiche les derniers commentaires');
@define('PLUGIN_COMMENTS_WORDWRAP', 'Retour � la ligne');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Faire un retour a la ligne automatique apr�s X mots. Valeur par d�faut: 30');
@define('PLUGIN_COMMENTS_MAXCHARS', 'Caract�res par commentaire');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Afficher X caract�res de chaque commentaire. Valeur par d�faut: 120');
@define('PLUGIN_COMMENTS_MAXENTRIES', 'Nombre de commentaires');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'D�finit combien de commentaires vont �tre affich�s. Valeur par d�faut: 15');
@define('PLUGIN_COMMENTS_ABOUT', '%s � propos%s');
@define('PLUGIN_COMMENTS_ANONYMOUS', 'anonyme');


/* vim: set sts=4 ts=4 expandtab : */
?>