<?php # $Id: lang_is.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_COMMENTS_BLAHBLAH', 'S�nir s��ustu athugasemdir � f�rslurnar ��nar');
        @define('PLUGIN_COMMENTS_WORDWRAP', 'L�nuskil');
        @define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Hversu m�rg or� �ar til l�nuskil eiga s�r sta�? (Sj�lfgefi� gildi: 30)');
        @define('PLUGIN_COMMENTS_MAXCHARS', 'H�marksstafafj�ldi � athugasemd');
        @define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Hversu margir stafir eiga a� vera birtir fyrir hverja athugasemd? (Sj�lfgefi� gildi: 120)');
        @define('PLUGIN_COMMENTS_MAXENTRIES', 'H�marksfj�ldi athugasemda');
        @define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Hversu margar athugasemdir skal s�na? (Sj�lfgefi� gildi: 15)');
        @define('PLUGIN_COMMENTS_ABOUT', '%s um%s');
/* vim: set sts=4 ts=4 expandtab : */
?>