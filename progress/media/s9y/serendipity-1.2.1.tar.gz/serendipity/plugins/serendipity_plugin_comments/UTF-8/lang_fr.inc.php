<?php # $Id: lang_fr.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_COMMENTS_BLAHBLAH', 'Affiche les derniers commentaires');
@define('PLUGIN_COMMENTS_WORDWRAP', 'Retour à la ligne');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Faire un retour a la ligne automatique après X mots. Valeur par défaut: 30');
@define('PLUGIN_COMMENTS_MAXCHARS', 'Caractères par commentaire');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Afficher X caractères de chaque commentaire. Valeur par défaut: 120');
@define('PLUGIN_COMMENTS_MAXENTRIES', 'Nombre de commentaires');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Définit combien de commentaires vont être affichés. Valeur par défaut: 15');
@define('PLUGIN_COMMENTS_ABOUT', '%s à propos%s');
@define('PLUGIN_COMMENTS_ANONYMOUS', 'anonyme');


/* vim: set sts=4 ts=4 expandtab : */
?>