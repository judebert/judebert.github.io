<?php # $Id: lang_ja.inc.php 1712 2007-06-06 04:23:06Z elf2000 $

/**
 *  @version $Revision: 1712 $
 *  @author Tadashi Jokagi <elf2000@users.sourceforge.net>
 *  EN-Revision: 1381
 */

@define('PLUGIN_COMMENTS_BLAHBLAH', 'あなたのエントリへの最後のコメントを表示します。');
@define('PLUGIN_COMMENTS_WORDWRAP', '禁則処理');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', '禁則処理するまでそれくらいの単語が現れますか? (デフォルト: 30)');
@define('PLUGIN_COMMENTS_MAXCHARS', 'コメントの最大文字数');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', '各コメントで何文字位表示しますか? (デフォルト: 120)');
@define('PLUGIN_COMMENTS_MAXENTRIES', 'コメントの最大数');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'どれくらいのコメントを表示しますか? (デフォルト: 15)');
@define('PLUGIN_COMMENTS_ABOUT', 'コメント: %s<br />%s');
@define('PLUGIN_COMMENTS_ANONYMOUS', '匿名');
?>
