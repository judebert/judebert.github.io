<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_COMMENTS_BLAHBLAH', 'Zeigt die letzten Kommentare');
        @define('PLUGIN_COMMENTS_WORDWRAP', 'Zeilenumbruch');
        @define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Nach wievielen Wörtern soll ein Zeilenumbruch eingefügt werden? (Standard: 30)');
        @define('PLUGIN_COMMENTS_MAXCHARS', 'Zeichen pro Kommentar');
        @define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Wieviele Zeichen sollen pro Kommentar gezeigt werden? (Standard: 120)');
        @define('PLUGIN_COMMENTS_MAXENTRIES', 'Anzahl an Kommentaren');
        @define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Wieviele Kommentare sollen gezeigt werden? (Standard: 15)');
        @define('PLUGIN_COMMENTS_ABOUT', '%s zu%s');
