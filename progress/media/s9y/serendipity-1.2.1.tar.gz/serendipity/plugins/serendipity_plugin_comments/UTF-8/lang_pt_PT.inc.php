<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# João P Matos <jmatos@math.ist.utl.pt>                                  #
# based on the french translation by                                     #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_COMMENTS_BLAHBLAH', 'Afixar os últimos comentários');
@define('PLUGIN_COMMENTS_WORDWRAP', 'Mudar de linha');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Mudar de linha automaticamente depois de X palavras. Valor por omissão: 30');
@define('PLUGIN_COMMENTS_MAXCHARS', 'Caracteres por comentário');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Afixar X caracteres por comentário. Valor por omissão: 120');
@define('PLUGIN_COMMENTS_MAXENTRIES', 'Número de comentários');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Define quantos comentários vão ser afixados. Valor por omissão: 15');
@define('PLUGIN_COMMENTS_ABOUT', '%s a propósito de%s');

/* vim: set sts=4 ts=4 expandtab : */
?>