<?php # $Id: lang_ja.inc.php,v 1.4 2005/05/17 11:37:42 garvinhicking Exp $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Jo�o P Matos <jmatos@math.ist.utl.pt>                                  #
# based on the french translation by                                     #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_COMMENTS_BLAHBLAH', 'Afixar os �ltimos coment�rios');
@define('PLUGIN_COMMENTS_WORDWRAP', 'Mudar de linha');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Mudar de linha automaticamente depois de X palavras. Valor por omiss�o: 30');
@define('PLUGIN_COMMENTS_MAXCHARS', 'Caracteres por coment�rio');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Afixar X caracteres por coment�rio. Valor por omiss�o: 120');
@define('PLUGIN_COMMENTS_MAXENTRIES', 'N�mero de coment�rios');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Define quantos coment�rios v�o ser afixados. Valor por omiss�o: 15');
@define('PLUGIN_COMMENTS_ABOUT', '%s a prop�sito de%s');

/* vim: set sts=4 ts=4 expandtab : */
?>