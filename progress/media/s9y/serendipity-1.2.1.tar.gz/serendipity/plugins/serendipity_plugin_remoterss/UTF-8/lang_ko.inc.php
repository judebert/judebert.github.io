<?php # $Id: lang_ko.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_REMOTERSS_TITLE', '원격 RSS/OPML-블로그롤 피드');
        @define('PLUGIN_REMOTERSS_BLAHBLAH', '원격 RSS/OPML 피드의 아이템을 보여줌 (블로그롤 등)');
        @define('PLUGIN_REMOTERSS_NUMBER', '글의 수');
        @define('PLUGIN_REMOTERSS_NUMBER_BLAHBLAH', '몇 개의 글을 보여주겠습니까? (기본값: 피드에 있는 모든 글)');
        @define('PLUGIN_REMOTERSS_SIDEBARTITLE', '피드의 제목');
        @define('PLUGIN_REMOTERSS_SIDEBARTITLE_BLAHBLAH', '블로그 옆줄에 나타낼 피드의 제목');
        @define('PLUGIN_REMOTERSS_RSSURI', 'RSS/OPML URI');
        @define('PLUGIN_REMOTERSS_RSSURI_BLAHBLAH', '표시할 RSS/OPML 피드의 URI');
        @define('PLUGIN_REMOTERSS_NOURI', 'RSS/OPML 피드가 선택되지 않음');
        @define('PLUGIN_REMOTERSS_RSSTARGET', 'RSS/OPML 링크 출력 대상');
        @define('PLUGIN_REMOTERSS_RSSTARGET_BLAHBLAH', '표시된 RSS 아이템의 링크를 출력할 대상 (기본값: _blank)');
        @define('PLUGIN_REMOTERSS_CACHETIME', '피드 갱신 주기');
        @define('PLUGIN_REMOTERSS_CACHETIME_BLAHBLAH', '피드 내용은 캐시에 저장되었다가 X 초가 지나면 갱신이 됨 (기본값: 3시간)');
        @define('PLUGIN_REMOTERSS_FEEDTYPE', '피드 종류');
        @define('PLUGIN_REMOTERSS_FEEDTYPE_BLAHBLAH', '원격 피드의 형태를 선택');
        @define('PLUGIN_REMOTERSS_BULLETIMG', '글머리표 그림');
        @define('PLUGIN_REMOTERSS_BULLETIMG_BLAHBLAH', '각 제목 앞에 표시될 그림 지정');
        @define('PLUGIN_REMOTERSS_DISPLAYDATE', '날짜 표시');
        @define('PLUGIN_REMOTERSS_DISPLAYDATE_BLAHBLAH', '제목 밑에 날짜를 표시');

?>
