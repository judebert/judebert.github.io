<?php
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								                                 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_EVENT_EMOTICATE_NAME', '標記語言: 表情圖案');
        @define('PLUGIN_EVENT_EMOTICATE_DESC', '轉換字串成表情圖案');
        @define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', '字串像 :-) 和 ;-) 會轉換成圖案。');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'File extension');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'The file extension of your emoticons. This is case sensitive.');
?>