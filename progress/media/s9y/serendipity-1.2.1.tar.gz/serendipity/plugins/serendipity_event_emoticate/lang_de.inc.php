<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'Textformatierung: Smilies');
@define('PLUGIN_EVENT_EMOTICATE_DESC', 'Standard Text-Smilies in Grafiken konvertieren');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Standard-Text Smilies wie :-) und ;-) werden zu Bildern konvertiert.');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'Dateinamenerweiterung');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'Die Dateinamenerweiterung der Emoticons. Gro�-/Kleinschreibung beachten.');
