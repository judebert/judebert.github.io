<?php # $Id: lang_is.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_SPARTACUS_NAME', 'Spartacus');
        @define('PLUGIN_EVENT_SPARTACUS_DESC', '[S]erendipity [P]lugin [A]ccess [R]epository [T]ool [A]nd [C]ustomization/[U]nification [S]ystem - Leyfir þér að sækja viðbætur úr netgagnabankanum okkar');
        @define('PLUGIN_EVENT_SPARTACUS_FETCH', 'Smelltu hér til að sækja nýja %s úr Serendipity netgagnabankanum');
        @define('PLUGIN_EVENT_SPARTACUS_FETCHERROR', 'Slóðin %s gat ekki verið opnuð. Kannski er Serendipity eða SourceForge.net þjónnin niðri - við biðjumst afsökunar, þú þarft að reyna aftur síðar.');
        @define('PLUGIN_EVENT_SPARTACUS_FETCHING', 'Reyni að opna slóðina %s...');
        @define('PLUGIN_EVENT_SPARTACUS_FETCHED_BYTES_URL', 'Sótti %s byte frá ofangreindri slóð. Vistaði skrá sem %s...');
        @define('PLUGIN_EVENT_SPARTACUS_FETCHED_BYTES_CACHE', 'Sótti %s byte frá skrá sem var þegar til á þjóninum þínum. Vistaði skrá sem %s...');
        @define('PLUGIN_EVENT_SPARTACUS_FETCHED_DONE', 'Niðurhali gagna lokið.');
