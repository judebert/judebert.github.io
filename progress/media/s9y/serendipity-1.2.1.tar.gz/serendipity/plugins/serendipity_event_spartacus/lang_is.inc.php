<?php # $Id: lang_is.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_SPARTACUS_NAME', 'Spartacus');
        @define('PLUGIN_EVENT_SPARTACUS_DESC', '[S]erendipity [P]lugin [A]ccess [R]epository [T]ool [A]nd [C]ustomization/[U]nification [S]ystem - Leyfir ��r a� s�kja vi�b�tur �r netgagnabankanum okkar');
        @define('PLUGIN_EVENT_SPARTACUS_FETCH', 'Smelltu h�r til a� s�kja n�ja %s �r Serendipity netgagnabankanum');
        @define('PLUGIN_EVENT_SPARTACUS_FETCHERROR', 'Sl��in %s gat ekki veri� opnu�. Kannski er Serendipity e�a SourceForge.net �j�nnin ni�ri - vi� bi�jumst afs�kunar, �� �arft a� reyna aftur s��ar.');
        @define('PLUGIN_EVENT_SPARTACUS_FETCHING', 'Reyni a� opna sl��ina %s...');
        @define('PLUGIN_EVENT_SPARTACUS_FETCHED_BYTES_URL', 'S�tti %s byte fr� ofangreindri sl��. Vista�i skr� sem %s...');
        @define('PLUGIN_EVENT_SPARTACUS_FETCHED_BYTES_CACHE', 'S�tti %s byte fr� skr� sem var �egar til � �j�ninum ��num. Vista�i skr� sem %s...');
        @define('PLUGIN_EVENT_SPARTACUS_FETCHED_DONE', 'Ni�urhali gagna loki�.');
