<?php
if (IN_serendipity !== true) {
    die ("Don't hack!");
}

# (c) 2005 by Alexander 'dma147' Mieland, http://blog.linux-stats.org, <dma147@linux-stats.org>
# Contact me on IRC in #linux-stats, #archlinux, #archlinux.de, #s9y on irc.freenode.net

// Probe for a language include with constants. Still include defines later on, if some constants were missing
$probelang = dirname(__FILE__) . '/' . $serendipity['charset'] . 'lang_' . $serendipity['lang'] . '.inc.php';
if (file_exists($probelang)) {
    include $probelang;
}

include dirname(__FILE__) . '/lang_en.inc.php';

#########################################################################################


class serendipity_event_advtypes extends serendipity_event {

    var $debug;

    function introspect(&$propbag) {
        global $serendipity;

        $propbag->add('name',          PLUGIN_ADVTYPES_TITLE);
        $propbag->add('description',   PLUGIN_ADVTYPES_DESC);
        $propbag->add('requirements',  array(
            'serendipity' => '1.1',
            'smarty'      => '2.6.7',
            'php'         => '4.1.0'
        ));

        $propbag->add('version',       '0.1');
        $propbag->add('author',       'Judebert http://judebert.com/');
        $propbag->add('stackable',     false);
        $propbag->add('event_hooks',   array(
            'backend_header'              => true,
            'backend_pluginconfig_media'  => true,
        ));
        //$propbag->add('configuration', array('unused'));
        $propbag->add('groups', array('Backend:Templates'));
        //$this->dependencies = array('serendipity_event_entryproperties' => 'keep');
    }

    function introspect_config_item($name, &$propbag) {
        global $serendipity;
        
        switch($name) {
            case 'unused' :
                $propbag->add('type', 'string');
                $propbag->add('name', 'unused');
                $propbag->add('description', 'unused');
                $propbag->add('default', 'unused');
                break;
                
            default:
                return false;
        }
        return true;
    }

    
    function generate_content(&$title) {
        $title = PLUGIN_ADVTYPES_TITLE;
    }

    function event_hook($event, &$bag, &$eventData, $addlData) {
        global $serendipity;
        
        $hooks = &$bag->get('event_hooks');
        if (isset($hooks[$event])) {
            switch($event) {
            case 'backend_header':
                // Output the JavaScript, if we must
                $getModule = $serendipity['GET']['adminModule'];
                $postModule = $serendipity['POST']['adminModule'];
                if ($getModule == 'templates' || $postModule == 'templates' || $getModule == 'plugins' || $postModule == 'plugins') {
                    $media_js = serendipity_getTemplateFile('media_input.js');
                    print <<<EOS
<script type="text/javascript" language="JavaScript" src="serendipity_editor.js"></script>
<script type="text/javascript">
function change_preview(id)
{
    var text_box = document.getElementById("serendipity[template][" + id + "]");
    var image_box = document.getElementById(id + "_preview"); 
    var filename = text_box.value;
    image_box.style.backgroundImage = "url(" + filename + ")";
}
function choose_media(id)
{
    target_id = id;

    window.open('serendipity_admin_image_selector.php?serendipity[htmltarget]=' + target_id + '&serendipity[filename_only]=true', 'ImageSel', 'width=800,height=600,toolbar=no,scrollbars=1,scrollbars,resize=1,resizable=1');
}
</script>

EOS;
                }
                break;

            case 'backend_pluginconfig_media':
                // Print the HTML to display the popup media selector
                $postKey = $eventData['postKey'];
                $var = $eventData['config_item'];
                $savedValue = $eventData['value'];
                $cbag = $eventData['cbag'];
                $cname = $cbag->get('name');
                $cdesc = $cbag->get('description');
                $preview_width = $cbag->get('preview_width');
                if (!$preview_width || $preview_width == "") {
                  $preview_width = '400px';
                }
                $preview_height = $cbag->get('preview_height');
                if (!$preview_height || $preview_height == "") {
                  $preview_img_height = '100px';
                }
                $media_link_text = MEDIA_LIBRARY;
                print <<<EOS
<tr><td colspan="2">
  <strong>$cname</strong>
  <br /><span style="color: #5E7A94; font-size: 8pt;">$cdesc</span>
</td> </tr>
<tr>
  <td style="border-bottom: 1px solid #000000">
    <!-- <img id="{$var}_preview" src="$savedValue"> -->
    <div id="{$var}_preview" style="background-image: url($savedValue); width:$preview_width; height: $preview_height;">&nbsp;</div>
  </td>
  <td style="border-bottom: 1px solid #000000">
    <input type="text" id="serendipity[$postKey][$var]" name="serendipity[$postKey][$var]" value="$savedValue"  onchange="change_preview('$var')"/>
    <br /><a href="#" onclick="choose_media('serendipity[$postKey][$var]')">$media_link_text</a>
  </td>
</tr>
EOS;
                return true;
                break;
            }
        }
        return true;
    }
}

/* vim: set sw=4 sts=4 ts=4 expandtab : */
