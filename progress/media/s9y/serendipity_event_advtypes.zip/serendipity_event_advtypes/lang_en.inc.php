<?php # $Id: lang_en.inc.php,v 1.1 2005/11/18 07:36:08 elf2000 Exp $

/**
 *  @version $Revision: 1.1 $
 *  @author Translator Name <yourmail@example.com>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define("PLUGIN_ADVTYPES_TITLE", "Advanced configuration types");
@define("PLUGIN_ADVTYPES_DESC", "Provides javascript output of recent entries for inclusion on other, extern websites. (see the README in the plugins directory!)");
?>
