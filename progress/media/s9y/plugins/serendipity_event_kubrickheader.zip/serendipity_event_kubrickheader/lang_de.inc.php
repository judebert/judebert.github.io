<?php # $Id: lang_de.inc.php,v 1.2 2005/12/06 20:25:29 garvinhicking Exp $

        @define('PLUGIN_EVENT_KUBRICKHEADER_STYLE_DESC',     'Welchen Style benutzen Sie ?');
        @define('PLUGIN_EVENT_KUBRICKHEADER_STYLE_DESC_BLAH',	'W�hlen Sie den Style, den Sie f�r den Blog benutzen');
        @define('PLUGIN_EVENT_KUBRICKHEADER_NAME',     'Kubrick/Joshua-Template Bild im Kopfbereich');
        @define('PLUGIN_EVENT_KUBRICKHEADER_KUBRICK',     'Kubrick');
        @define('PLUGIN_EVENT_KUBRICKHEADER_JOSHUA',     'Joshua');
        @define('PLUGIN_EVENT_KUBRICKHEADER_DESC',     'Wechselt das Bild im Kubrick/Joshua-Template');
        @define('PLUGIN_EVENT_KUBRICKHEADER_IMAGE',     'Bild');
        @define('PLUGIN_EVENT_KUBRICKHEADER_IMAGE_DESC',  'Entweder direkt ein Bild eingeben oder den Namen eines Verzeichnisses (mit abschlie�endem Slash) eingeben, und das Plugin wird zuf�llig ein .jpg/.jpeg/.png Bild dieses Verzeichnisses ausw�hlen.');
