<?php # $Id: lang_en.inc.php,v 1.0 2006/11/25 18:52:56 slothman Exp $

/**
 *  @version $Revision: 1.0 $
 *  @author Translator Name <judebert@judebert.com>
 *  EN-Revision: 1.0
 */

@define('PLUGIN_SHOUTCAST_DATA_NAME', 'Shoutcast Data on Page');
@define('PLUGIN_SHOUTCAST_DATA_DESC', 'Puts data from a Shoutcast server within the page.');
@define('PLUGIN_SHOUTCAST_DATA_PLACE', 'Nugget Placement');
@define('PLUGIN_SHOUTCAST_DATA_TOP', 'Top of the content');
@define('PLUGIN_SHOUTCAST_DATA_ART_FOOT', 'Footer for the article');
@define('PLUGIN_SHOUTCAST_DATA_BOTTOM', 'Bottom of the content');
@define('PLUGIN_SHOUTCAST_DATA_FOOT', 'End of the page');
@define('PLUGIN_SHOUTCAST_DATA_NOSHOW', ' It does not show up on the actual page.');
@define('PLUGIN_SHOUTCAST_DATA_SERVER', 'Shoutcast Host');
@define('PLUGIN_SHOUTCAST_DATA_SERVER_DESC', 'Name or IP address of the Shoutcast server');
@define('PLUGIN_SHOUTCAST_DATA_PORT', 'Shoutcast Port');
@define('PLUGIN_SHOUTCAST_DATA_PORT_DESC', 'Port of the Shoutcast server (your hosting service must not block this port for outgoing connections, or no data will ever be returned)');
@define('PLUGIN_SHOUTCAST_DATA_PASS', 'Shoutcast Admin Password');
@define('PLUGIN_SHOUTCAST_DATA_PASS_DESC', 'Password to access data on the Shoutcast server');
// Default template data
@define('PLUGIN_SHOUTCAST_PLAYTIME_FORMAT', '%r');
@define('PLUGIN_SHOUTCAST_LATEST_SONGS', 'Latest songs from ');
@define('PLUGIN_SHOUTCAST_MY_FAVORITE', ', my favorite');
@define('PLUGIN_SHOUTCAST_STATION', ' station');
?>
