<?php # $Id: serendipity_event_shoutcast_data.php,v 1.0 2006/11/25:52:56 slothman Exp $

// Probe for a language include with constants. Still include defines later on, if some constants were missing
$probelang = dirname(__FILE__) . '/' . $serendipity['charset'] . 'lang_' . $serendipity['lang'] . '.inc.php';
if (file_exists($probelang)) {
    include $probelang;
}

include dirname(__FILE__) . '/lang_en.inc.php';

class serendipity_event_shoutcast_data extends serendipity_event
{
    function introspect(&$propbag)
    {
        global $serendipity;

        $propbag->add('name',          PLUGIN_SHOUTCAST_DATA_NAME);
        $propbag->add('description',   PLUGIN_SHOUTCAST_DATA_DESC);
        $propbag->add('stackable',     true);
        $propbag->add('author',        'Jude Anthony');
        $propbag->add('version',       '1.0');
        $propbag->add('requirements',  array(
            'serendipity' => '0.8',
            'smarty'      => '2.6.7',
            'php'         => '4.1.0'
        ));
        $propbag->add('groups', array('FRONTEND_ENTRY_RELATED'));
        $propbag->add('event_hooks',   array(
                                             'entries_header' => true,
                                             'entry_display' => true,
                                             'entries_footer' => true,
                                             'frontend_footer' => true));
        $propbag->add('configuration', array('title', 'show_where', 'placement', 'server', 'port', 'pass'));
    }

    function introspect_config_item($name, &$propbag)
    {
        switch($name) {

            case 'title':
                $propbag->add('type',        'string');
                $propbag->add('name',        TITLE);
                $propbag->add('description', TITLE_FOR_NUGGET . PLUGIN_SHOUTCAST_DATA_NOSHOW);
                $propbag->add('default',     '');
                break;

            case 'placement':
                $select = array(
                                'top' => PLUGIN_SHOUTCAST_DATA_TOP,
                                'art_foot' => PLUGIN_SHOUTCAST_DATA_ART_FOOT,
                                'bottom' => PLUGIN_SHOUTCAST_DATA_BOTTOM,
                                'foot' => PLUGIN_SHOUTCAST_DATA_FOOT);
                $propbag->add('type',        'select');
                $propbag->add('select_values', $select);
                $propbag->add('name',        PLUGIN_SHOUTCAST_DATA_PLACE);
                $propbag->add('default',     'top');
                break;

            case 'server':
                $propbag->add('type',        'string');
                $propbag->add('name',        PLUGIN_SHOUTCAST_DATA_SERVER);
                $propbag->add('description', PLUGIN_SHOUTCAST_DATA_SERVER_DESC);
                $propbag->add('default',     '127.0.0.1');
                break;

            case 'port':
                $propbag->add('type',        'string');
                $propbag->add('name',        PLUGIN_SHOUTCAST_DATA_PORT);
                $propbag->add('description', PLUGIN_SHOUTCAST_DATA_PORT_DESC);
                $propbag->add('default',     '8000');
                break;

            case 'pass':
                $propbag->add('type',        'string');
                $propbag->add('name',        PLUGIN_SHOUTCAST_DATA_PASS);
                $propbag->add('description', PLUGIN_SHOUTCAST_DATA_PASS_DESC);
                $propbag->add('default',     '');
                break;

            case 'show_where':
                $select = array('extended' => PLUGIN_ITEM_DISPLAY_EXTENDED, 'overview' => PLUGIN_ITEM_DISPLAY_OVERVIEW, 'both' => PLUGIN_ITEM_DISPLAY_BOTH);
                $propbag->add('type',        'select');
                $propbag->add('select_values', $select);
                $propbag->add('name',        PLUGIN_ITEM_DISPLAY);
                $propbag->add('default',     'both');
                break;

            default:
                return false;
        }
        return true;
    }

    function generate_content(&$title)
    {
        $title = $this->get_config('title');
    }

    function event_hook($event, &$bag, &$eventData, $addData = null) {
        global $serendipity;

        $hooks = &$bag->get('event_hooks');
        $placement = $this->get_config('placement', 'top');
        $show_where = $this->get_config('show_where', 'both');
        $server = $this->get_config('server', '127.0.0.1');
        $port = $this->get_config('port', '8000');
        $pass = $this->get_config('pass', '');
        // conditions for showing the data
        if ($show_where == 'extended' && (!isset($serendipity['GET']['id']) || !is_numeric($serendipity['GET']['id']))) {
            return false;
        } else if ($show_where == 'overview' && isset($serendipity['GET']['id']) && is_numeric($serendipity['GET']['id'])) {
            return false;
        }

        if (($placement == 'top' && $event == 'entries_header') ||
            ($placement == 'bottom' && $event == 'entries_footer') ||
            ($placement == 'foot' && $event == 'frontend_footer')){
            // entries_footer hook location workaround: get out of the 'serendipity_entryFooter' class
            if ($event == 'entries_footer') echo '</div><div>';
            // Output here
            print $this->get_shoutcast_data($server, $port, $pass);
            return true;
        } elseif ($placement == 'art_foot' && $event == 'entry_display'){
            if (!is_array($eventData)) return false;
            $elements = count($eventData);
            for ($i = 0; $i < $elements; $i++) {
                $eventData[$i]['add_footer'] .= sprintf('</div>' . $this->get_shoutcast_data($server, $port, $pass) . '<div>');
            }
        } else {
            return false;
        }
    }

    function get_shoutcast_data($scip, $scport, $scpass) {
        global $serendipity;

	// Set up a default result if everything goes wrong
        $result = '<b>Error processing Shoutcast data</b><br />';
	// The ShoutCast data as an array
	$scdata = array();

        // Connect to the server
        $scfp = @fsockopen("$scip", $scport, &$errno, &$errstr, 30);
        if(!$scfp) {
            $scsuccs=1;
            $result = 'Unable to connect to '.$scip.':'.$scport.'<br/>(Error #'.$errno.': '.$errstr.')';
        }
        if($scsuccs!=1){
            //for newer shoutcast servers
	    $request = "GET /admin.cgi?mode=viewxml HTTP/1.1\r\nHost: $scip:$scport\r\n".
                "User-Agent: Serendipity Shoutcast Data Plugin(author: judebert@judebert.com, from code by dstjohn@mediacast1.com)(Mozilla Compatible)\r\n" .
                'Authorization: Basic '.base64_encode("admin:$scpass")."\r\n\r\n";
	    fputs ($scfp, $request);
            while(!feof($scfp)) {
                $xml_data .= fgets($scfp, 1000);
            }
            fclose($scfp);

	    // Get important tags
	    //
	    // Add extra tags here, with their Smarty data equivalents
            $tags = array(
		'SERVERTITLE' => 'server_title', 
		'SERVERURL' => 'server_url', 
	        'STREAMSTATUS' => 'status', 
		'BITRATE' => 'bitrate', 
		'SERVERGENRE' => 'genre',
		);
            foreach($tags as $tag => $smarty_value) {
                $text = ereg_replace(".*<$tag>", "", $xml_data);
                $text = ereg_replace("</$tag>.*", "", $text);
		$val = urldecode($text);
		$scdata[$smarty_value] = $val;
		if ($tag == 'SERVERTITLE') {
		   $scdata['css_class'] = 'shoutcast_' . preg_replace('/[^A-Za-z0-9]/', '', $val);
		}
            }

	    // Get songlist, with titles and playtimes
	    $scsongs = array();  // Array to store data
	    $text_result = null;  // Result if no songs
            $text = ereg_replace(".*<SONGHISTORY>", "", $xml_data);
            $text = ereg_replace("</SONGHISTORY>.*", "", $text);
            $eachsong = explode("<SONG>", $text);
            foreach ($eachsong as $songdata) {
		// First is blank because explode() delimiter starts the string
	        if ($songdata == "") continue;

		// Get the playtime
                $playtime = ereg_replace(".*<PLAYEDAT>", "", $songdata);
                $playtime = ereg_replace("</PLAYEDAT>.*", "", $playtime);
		// Get the decoded title
                $title = ereg_replace(".*<TITLE>", "", $songdata);
                $title = ereg_replace("</TITLE>.*", "", $title);
                $title = urldecode($title);

                //format the date
                //$frmt_date = date('l dS of F Y h:i:s A',$playtime);
                $frmt_date = date('h:i:s A',$playtime);

		// Add to song array
		$song = array(
		    'title' => $title, 
		    'playtime' => $playtime,
		    'formatted_playtime' => $frmt_date, 
		);
		$scsongs[] = $song;

                // You may add extra text results here if you like, but it's
		// better to do the real job in the Smarty template.
                $text_result .= '<b>* </b>'.$title.'<BR>';
            }
	    // Get default text result
	    if ($text_result != null) {
	        $result = $text_result;
	    }
	    // Add song array to ShoutCast data
	    $scdata['songs'] = $scsongs;

	    // Smarty templating of result
	    //
	    serendipity_smarty_init();

	    // Give the ShoutCast data to Smarty
	    $serendipity['smarty']->assign('shoutcast_data', $scdata);

	    // Retrieve the template from the Serendipity path or the plugin directory
	    $filename = 'plugin_shoutcast_data.tpl';
	    $filename = basename($filename);
	    $templatefile = serendipity_getTemplateFile($filename, 'serendipityPath');
	    if (!$templatefile) {
	        $templatefile = dirname(__FILE__) . '/' . $filename;
            }

	    // Must remove security restrictions to use files in current directory
	    //
	    // Save security setting
	    $old_security = $serendipity['smarty']->security_settings[INCLUDE_ANY];
	    // Remove restrictions
	    $serendipity['smarty']->security_settings[INCLUDE_ANY] = true;
	    // Actually do the formatting
	    $smarty_result = null;
	    $smarty_result = @$serendipity['smarty']->fetch('file:'. $templatefile, null, null, false);
	    // Restore restrictions
	    $serendipity['smarty']->security_settings[INCLUDE_ANY] = $old_security;

	    // Did we get a good result?
	    if ($smarty_result) {
	        $result = $smarty_result;
	    } else {
	        $result = 'Text-only songlist:<br />' . $result;
	    }
        } 

        return $result;
    }
}

