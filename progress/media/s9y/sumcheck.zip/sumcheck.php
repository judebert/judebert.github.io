<?php # $Id: functions_installer.inc.php 2371 2008-11-12 13:32:24Z garvinhicking $
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity Developer Team)
# All rights reserved.  See LICENSE file for licensing details

/**
 * Retrieve an FTP-compatible checksum for a file.
 *
 * @access public
 * @param string filename is the path to the file to checksum
 * @param string type forces a particular interpretation of newlines.  Mime
 *    types and strings starting with 'text' will cause newlines to be stripped
 *    before the checksum is calculated (default: null, determine from finfo 
 *    and extension)
 * @return string An MD5 checksum of the file, with newlines removed if it's 
 *    an ASCII type; or false if the file cannot be read
 */
function serendipity_FTPChecksum($filename, $type = null) {
    /** Only read the finfo database once */
    static $debug_exts = array();

    // Must be able to read the file 
    if (!is_readable($filename)) {
        return false;
    }

    // Figure out whether it's binary or text by extension
    if ($type == null) {
        $parts = pathinfo($filename);
        $ext = '';
        // Some PHP versions throw a warning if the index doesn't exist
        if (isset($parts['extension'])) {
            $ext = $parts['extension'];
        }
        // If they're case-insensitive equal, strcasecmp() returns 0, or
        // 'false'.  So I use && to find if any of them are 0, in the
        // most likely fail-fast order.
        if (strcasecmp($ext, 'php') && 
            strcasecmp($ext, 'tpl') &&
            strcasecmp($ext, 'sql') &&
            strcasecmp($ext, 'js') && 
            strcasecmp($ext, 'txt') && 
            strcasecmp($ext, 'htc') && 
            strcasecmp($ext, 'css') && 
            strcasecmp($ext, 'dist') && 
            strcasecmp($ext, 'lib') && 
            strcasecmp($ext, 'sh') && 
            strcasecmp($ext, 'html') &&
            strcasecmp($ext, 'htm') &&
            !empty($ext)) {
            if (!in_array($ext, array_keys($debug_exts))) {
                $debug_exts[$ext] = $filename;
            }
            $type = 'bin';
        } else {
            $type = 'text';
        }
    }

    // Calculate the checksum
    $md5 = false;
    if (stristr($type, 'text')) {
        // This is a text-type file.  We need to remove linefeeds before 
        // calculating a checksum, to account for possible FTP conversions
        // that are inconvenient, but still valid.  But we don't want to
        // allow newlines anywhere; just different *kinds* of newlines.
        $newlines = array("#\r\n#", "#\r#", "#\n#");
        $file = file_get_contents($filename);
        $file = preg_replace($newlines, ' ', $file);
        $md5 = md5($file);
    } else {
        // Just get its md5sum
        $md5 = md5_file($filename);
    }

    return $md5;
}

$sum_bin_text = serendipity_FTPChecksum('./screen.bin', 'text');
$sum_bin_auto = serendipity_FTPChecksum('./screen.bin');
$sum_bin_bin = serendipity_FTPChecksum('./screen.bin', 'bin');
$sum_auto_text = serendipity_FTPChecksum('./screen.css', 'text');
$sum_auto_auto = serendipity_FTPChecksum('./screen.css');
$sum_auto_bin = serendipity_FTPChecksum('./screen.css', 'bin');
$sum_ascii_text = serendipity_FTPChecksum('./screen.ascii.css', 'text');
$sum_ascii_auto = serendipity_FTPChecksum('./screen.ascii.css');
$sum_ascii_bin = serendipity_FTPChecksum('./screen.ascii.css', 'bin');

echo <<<EOS
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head><title>FTP Checksum Test</title></head>
<body>
<h2>Instructions</h2>
<p>Upload all the files to your server (you've already done that).</p>
<p><b>Make sure:</b></p>
<ol>
<li>screen.css is uploaded using your FTP program's automatic mode</li>
<li>screen.ascii.css is uploaded in ASCII mode</li>
<li>screen.bin is uploaded in BINARY mode.</li>
</ol>
<p>The files have identical contents, but have been named so that FTP programs should get it right.</p>
<p>Then call the sumcheck.php program from your browser (in my case, it was <a href="http://judebert.com/sumcheck.php">http://judebert.com/sumcheck.php</a>).  You've already done that, too, resulting in the table you see below.</p>
<table border='1'>
<tr><th>File</th><th>Binary Checksum</th><th>Auto Checksum</th><th>Text Checksum</th></tr>
<tr><td>screen.css (auto)</td><td>$sum_auto_bin</td><td>$sum_auto_auto</td><td>$sum_auto_text</td></tr>
<tr><td>screen.ascii.css (ascii)</td><td>$sum_ascii_bin</td><td>$sum_ascii_auto</td><td>$sum_ascii_text</td></tr>
<tr><td>screen.bin (binary)</td><td>$sum_bin_bin</td><td>$sum_bin_auto</td><td>$sum_bin_text</td></tr>
</table>
<h2>Expected results</h2>
<ol>
<li>The screen.ascii.css matches the screen.css in all three columns.
<ul><li>If this is not the case, your FTP client's automatic detection is not working properly.  It was supposed to upload screeen.css in ASCII mode, in which case it should be identical to screen.ascii.css, which you verfied was uploaded in ASCII mode.</li></ul>
</li>
<li>The Binary and Text checksums differ within each line.
<ul><li>If the Binary and Text checksums match on any particular line, that file has had all its newlines removed.  When a file is transferred in FTP's ASCII mode, newlines are supposed to be translated to match the server's newline style, not removed outright.  In particular, the checksum 6805c852e1bf14ac26d7c06288232eb9 in all three columns indicates that the newlines have been removed from the file altogether.  This problem is the result of an buggy FTP server.</li></ul>
</li>
<li>The Text Checksum for all three lines should be 7a68bb63d1fce7973ddc090cd81e92be.
<ul><li>This is the expected MD5 checksum of each file when all the possible newline styles are replaced with a space.  If this checksum is incorrect for any file, that file either has incorrectly modified contents <b>(see #2)</b> or PHP is not replacing regular expressions correctly.  Report any PHP problems to Judebert on the <a href="http://www.s9y.org/forums/">Serendipity Forums</a> immediately, along with your PHP version (see below).</li></ul>
</li>
<li>The Auto and Text checksums should match for screen.css and screen.ascii.css.  The Auto and Binary cheksums should match for screen.bin.
<ul><li>If this is not the case, your server's PHP library is not parsing file extensions properly.  You will never see this problem; if you ever do, contact Judebert through the Serendipity Forums immediately, and report your PHP version (see below)</li></ul>
</li>
</ol>
EOS;
echo "<p>Your PHP version: " . phpversion() . "</p>\n";
echo "</body>\n</html>\n";

/* vim: set sts=4 ts=4 sw=4 expandtab : */
